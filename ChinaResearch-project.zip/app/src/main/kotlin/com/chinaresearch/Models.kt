package com.chinaresearch

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

const val NF = "Information Not Found"

data class Requirement(
    val name: String = "", val chineseName: String = "", val category: String = "", val qty: String = "",
    val maxPrice: Double? = null, val currency: String = "USD", val maxMoq: Int? = null,
    val material: String = "", val size: String = "", val capacity: String = "", val voltage: String = "",
    val power: String = "", val performance: String = "", val certification: String = "",
    val customization: String = "", val country: String = "",
    val specs: List<Pair<String, String>> = emptyList(), val notes: String = ""
)

data class Source(
    val id: String, val name: String, val note: String,
    val url: (String, Requirement) -> String, val linkPattern: String
)

val SOURCES = listOf(
    Source("alibaba", "Alibaba.com", "Public search, usually no login",
        { q, _ -> "https://www.alibaba.com/trade/search?SearchText=" + Uri.encode(q) }, """\/product-detail\/"""),
    Source("mic", "Made-in-China", "Public search, usually no login",
        { q, _ -> "https://www.made-in-china.com/products-search/hot-china-products/" + Uri.encode(q.trim().replace(" ", "_")) + ".html" },
        """made-in-china\.com\/product\/"""),
    Source("gs", "Global Sources", "Experimental: page layout may differ",
        { q, _ -> "https://www.globalsources.com/searchList/products?keyWord=" + Uri.encode(q) }, """\d{8,}p\.htm"""),
    Source("1688", "1688.com", "Login / verification needed. Chinese name works best",
        { q, r -> "https://s.1688.com/selloffer/offer_search.htm?keywords=" + java.net.URLEncoder.encode(r.chineseName.ifBlank { q }, "GBK") },
        """detail\.1688\.com\/offer\/\d+""")
)

data class Product(
    val title: String, val url: String, val image: String?, val platform: String,
    val priceText: String?, val currency: String?, val minPrice: Double?, val maxPriceFound: Double?,
    val moqText: String?, val moq: Int?, val supplier: String? = null, val card: List<String> = emptyList()
)

data class PageData(
    val url: String, val title: String, val desc: String,
    val specs: List<Pair<String, String>>, val images: List<Pair<String, String>>,
    val facts: List<String>, val links: List<Pair<String, String>>,
    val supplierName: String?, val supplierUrl: String?, val priceLines: List<String>,
    val blocked: Boolean, val bodyLen: Int
)

enum class Status(val label: String) {
    MATCH("✅ Match"), NO("❌ Doesn't Match"), PARTIAL("⚠️ Partial / Unclear"), NA("— Information Unavailable")
}

data class Row(val param: String, val required: String, val found: String, val status: Status, val source: String)
data class Field(val label: String, val value: String?, val source: String = "")

data class Task(
    val kind: String, val label: String, val url: String, val js: String,
    val source: Source? = null, val product: Product? = null, val id: Long = System.nanoTime()
)

// ---------- JSON ----------
fun JSONArray.strs(): List<String> = (0 until length()).map { getString(it) }
fun JSONArray.pairs(): List<Pair<String, String>> = (0 until length()).map { val a = getJSONArray(it); a.getString(0) to a.getString(1) }
fun pairsJson(l: List<Pair<String, String>>): JSONArray { val arr = JSONArray(); l.forEach { arr.put(JSONArray().put(it.first).put(it.second)) }; return arr }
fun strsJson(l: List<String>): JSONArray { val arr = JSONArray(); l.forEach { arr.put(it) }; return arr }

fun Requirement.toJson(): JSONObject {
    val o = JSONObject()
    o.put("name", name); o.put("chineseName", chineseName); o.put("category", category); o.put("qty", qty)
    if (maxPrice != null) o.put("maxPrice", maxPrice)
    o.put("currency", currency)
    if (maxMoq != null) o.put("maxMoq", maxMoq)
    o.put("material", material); o.put("size", size); o.put("capacity", capacity); o.put("voltage", voltage)
    o.put("power", power); o.put("performance", performance); o.put("certification", certification)
    o.put("customization", customization); o.put("country", country); o.put("specs", pairsJson(specs)); o.put("notes", notes)
    return o
}

fun reqFrom(o: JSONObject) = Requirement(
    name = o.optString("name"), chineseName = o.optString("chineseName"), category = o.optString("category"),
    qty = o.optString("qty"), maxPrice = if (o.has("maxPrice")) o.getDouble("maxPrice") else null,
    currency = o.optString("currency", "USD"), maxMoq = if (o.has("maxMoq")) o.getInt("maxMoq") else null,
    material = o.optString("material"), size = o.optString("size"), capacity = o.optString("capacity"),
    voltage = o.optString("voltage"), power = o.optString("power"), performance = o.optString("performance"),
    certification = o.optString("certification"), customization = o.optString("customization"),
    country = o.optString("country"), specs = o.optJSONArray("specs")?.pairs() ?: emptyList(), notes = o.optString("notes")
)

fun Product.toJson(): JSONObject {
    val o = JSONObject()
    o.put("title", title); o.put("url", url); o.put("image", image ?: ""); o.put("platform", platform)
    o.put("priceText", priceText ?: ""); o.put("currency", currency ?: "")
    if (minPrice != null) o.put("minPrice", minPrice)
    if (maxPriceFound != null) o.put("maxPriceFound", maxPriceFound)
    o.put("moqText", moqText ?: "")
    if (moq != null) o.put("moq", moq)
    o.put("supplier", supplier ?: ""); o.put("card", strsJson(card))
    return o
}

fun productFrom(o: JSONObject) = Product(
    title = o.optString("title"), url = o.optString("url"), image = o.optString("image").ifBlank { null },
    platform = o.optString("platform"), priceText = o.optString("priceText").ifBlank { null },
    currency = o.optString("currency").ifBlank { null },
    minPrice = if (o.has("minPrice")) o.getDouble("minPrice") else null,
    maxPriceFound = if (o.has("maxPriceFound")) o.getDouble("maxPriceFound") else null,
    moqText = o.optString("moqText").ifBlank { null }, moq = if (o.has("moq")) o.getInt("moq") else null,
    supplier = o.optString("supplier").ifBlank { null }, card = o.optJSONArray("card")?.strs() ?: emptyList()
)

fun PageData.toJson(): JSONObject {
    val o = JSONObject()
    o.put("url", url); o.put("title", title); o.put("desc", desc); o.put("specs", pairsJson(specs))
    o.put("images", pairsJson(images)); o.put("facts", strsJson(facts)); o.put("links", pairsJson(links))
    o.put("supplierName", supplierName ?: ""); o.put("supplierUrl", supplierUrl ?: "")
    o.put("priceLines", strsJson(priceLines)); o.put("blocked", blocked); o.put("bodyLen", bodyLen)
    return o
}

fun pageFrom(o: JSONObject) = PageData(
    url = o.optString("url"), title = o.optString("title"), desc = o.optString("desc"),
    specs = o.optJSONArray("specs")?.pairs() ?: emptyList(), images = o.optJSONArray("images")?.pairs() ?: emptyList(),
    facts = o.optJSONArray("facts")?.strs() ?: emptyList(), links = o.optJSONArray("links")?.pairs() ?: emptyList(),
    supplierName = o.optString("supplierName").ifBlank { null }, supplierUrl = o.optString("supplierUrl").ifBlank { null },
    priceLines = o.optJSONArray("priceLines")?.strs() ?: emptyList(), blocked = o.optBoolean("blocked"), bodyLen = o.optInt("bodyLen")
)
