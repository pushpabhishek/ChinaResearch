package com.chinaresearch

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import org.json.JSONObject
import java.io.File

data class HistoryItem(val id: Long, val title: String, val date: String, val listings: Int, val details: Int)

class Store(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "history").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun save(s: Session) {
        if (s.id == 0L || s.products.isEmpty()) return
        val o = JSONObject()
        o.put("id", s.id); o.put("date", s.date); o.put("req", s.req.toJson())
        o.put("products", org.json.JSONArray().also { a -> s.products.forEach { a.put(it.toJson()) } })
        val d = JSONObject(); s.details.forEach { (k, v) -> d.put(k, v.toJson()) }; o.put("details", d)
        val u = JSONObject(); s.suppliers.forEach { (k, v) -> u.put(k, v.toJson()) }; o.put("suppliers", u)
        val st = JSONObject(); s.status.forEach { (k, v) -> st.put(k, v) }; o.put("status", st)
        File(dir, "${s.id}.json").writeText(o.toString())
    }

    fun list(): List<HistoryItem> = (dir.listFiles() ?: emptyArray()).mapNotNull { f ->
        try {
            val o = JSONObject(f.readText())
            HistoryItem(o.getLong("id"), reqFrom(o.getJSONObject("req")).name, o.optString("date"),
                o.getJSONArray("products").length(), o.getJSONObject("details").length())
        } catch (e: Exception) { null }
    }.sortedByDescending { it.id }

    fun load(id: Long, s: Session): Boolean {
        return try {
            val o = JSONObject(File(dir, "$id.json").readText())
            s.clearResults()
            s.id = o.getLong("id"); s.date = o.optString("date"); s.req = reqFrom(o.getJSONObject("req"))
            val a = o.getJSONArray("products")
            for (i in 0 until a.length()) s.products.add(productFrom(a.getJSONObject(i)))
            val d = o.getJSONObject("details"); d.keys().forEach { k -> s.details[k] = pageFrom(d.getJSONObject(k)) }
            val u = o.getJSONObject("suppliers"); u.keys().forEach { k -> s.suppliers[k] = pageFrom(u.getJSONObject(k)) }
            val st = o.getJSONObject("status"); st.keys().forEach { k -> s.status[k] = st.getString(k) }
            true
        } catch (e: Exception) { false }
    }

    fun delete(id: Long) { File(dir, "$id.json").delete() }
    fun deleteAll() { dir.listFiles()?.forEach { it.delete() } }

    fun loadSettings(s: Session) {
        val en = prefs.getStringSet("sources", null)
        if (en != null) { s.enabled.clear(); s.enabled.addAll(en) }
        s.desktop = prefs.getBoolean("desktop", true)
        s.inr = prefs.getString("inr", "") ?: ""
        s.cny = prefs.getString("cny", "") ?: ""
        s.applyRates()
    }

    fun saveSettings(s: Session) {
        prefs.edit().putStringSet("sources", s.enabled.toSet()).putBoolean("desktop", s.desktop)
            .putString("inr", s.inr).putString("cny", s.cny).apply()
        s.applyRates()
    }

    fun clearWebData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
    }
}
