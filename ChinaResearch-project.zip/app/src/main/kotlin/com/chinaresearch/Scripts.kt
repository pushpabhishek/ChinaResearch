package com.chinaresearch

// Dollar signs inside the JS use \x24 or only appear before a slash, so Kotlin raw strings never see a template.

// Search result page: finds the product cards. __PAT__ is replaced by the source's product-link pattern.
const val SEARCH_JS = """(function(){
var PAT=/__PAT__/i;
function key(h){return h.split('?')[0].split('#')[0];}
function T(e){return ((e&&e.innerText)||'').trim();}
var body=(document.body&&document.body.innerText)||'';
var bl=/captcha|verify you are human|unusual traffic|slide to verify|security check|验证码|滑动验证|请登录|sign in to continue/i;
var all=[].slice.call(document.querySelectorAll('a[href]')).filter(function(a){return PAT.test(a.href);});
var seen={},out=[];
all.forEach(function(a){
 var u=key(a.href); if(seen[u])return; seen[u]=1;
 var c=a;
 for(var i=0;i<14&&c.parentElement&&c.parentElement!==document.body;i++){
  var p=c.parentElement,ks={},n=0;
  var ls=p.querySelectorAll('a[href]');
  for(var j=0;j<ls.length;j++){if(PAT.test(ls[j].href)){var k=key(ls[j].href);if(!ks[k]){ks[k]=1;n++;}}}
  if(n>1)break; c=p;
 }
 var title='';
 var as=c.querySelectorAll('a[href]');
 for(var m=0;m<as.length;m++){if(key(as[m].href)===u){var t=(as[m].getAttribute('title')||T(as[m])||'').trim();if(t.length>title.length&&t.length<250)title=t;}}
 var im='',imgs=c.querySelectorAll('img');
 for(var q=0;q<imgs.length;q++){var s=imgs[q].currentSrc||imgs[q].getAttribute('data-src')||imgs[q].getAttribute('data-lazy-src')||imgs[q].src||'';if(s&&s.indexOf('data:')!==0){im=s;break;}}
 out.push({url:u,title:title,text:T(c).slice(0,1500),img:im});
});
return JSON.stringify({blocked:(bl.test(location.href)||(bl.test(body.slice(0,2500))&&out.length<3)),items:out});
})()"""

// Product page and supplier/company profile page
const val PAGE_JS = """(function(){
function T(e){return ((e&&e.innerText)||'').replace(/\s+/g,' ').trim();}
var body=(document.body&&document.body.innerText)||'';
var r={title:'',desc:'',specs:[],images:[],facts:[],links:[],supplier:'',priceLines:[],blocked:false,bodyLen:body.length};
r.title=T(document.querySelector('h1'))||document.title||'';
var md=document.querySelector('meta[name=description]')||document.querySelector('meta[property="og:description"]');
r.desc=md?(md.getAttribute('content')||'').slice(0,700):'';
r.blocked=/captcha|verify you are human|unusual traffic|slide to verify|security check|验证码|滑动验证|请登录/i.test(location.href+' '+body.slice(0,1500))&&body.length<2500;
var seenKV={};
function add(k,v){k=String(k||'').replace(/[:：]\s*$/,'').trim();v=String(v||'').trim();
 if(k.length<2||k.length>50||!v||v.length>250||k===v)return;
 if(/^[\d\s.,-]+$/.test(k))return;
 var id=k+'|'+v;if(seenKV[id])return;seenKV[id]=1;r.specs.push([k,v]);}
document.querySelectorAll('tr').forEach(function(t){var c=t.children;
 if(c.length==2)add(T(c[0]),T(c[1]));
 else if(c.length==4){add(T(c[0]),T(c[1]));add(T(c[2]),T(c[3]));}});
document.querySelectorAll('dl').forEach(function(d){var dt=d.querySelectorAll('dt'),dd=d.querySelectorAll('dd');for(var i=0;i<dt.length&&i<dd.length;i++)add(T(dt[i]),T(dd[i]));});
var els=document.querySelectorAll('div,li,p,span');
for(var e=0;e<els.length&&r.specs.length<320;e++){var ch=els[e].children;
 if(ch.length==2){var a=T(ch[0]),b=T(ch[1]);
  if(a.length>1&&a.length<45&&b.length>0&&b.length<200&&ch[0].children.length<2&&ch[1].children.length<3)add(a,b);}}
body.split('\n').forEach(function(l){l=l.trim();var m=l.match(/^([A-Za-z][A-Za-z \/&\-\.\(\)]{2,40})\s*[:：]\s*(.{1,200})/);if(m)add(m[1],m[2]);});
document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){try{
 var j=JSON.parse(s.textContent);var arr=Array.isArray(j)?j:[j];
 arr.forEach(function(o){if(o&&o['@type']=='Product'){
  if(o.brand)add('Brand',o.brand.name||o.brand);if(o.sku)add('SKU',o.sku);if(o.mpn)add('Model Number',o.mpn);
  var of=o.offers;if(of){var f=Array.isArray(of)?of[0]:of;
   if(f&&f.lowPrice)r.priceLines.unshift((f.priceCurrency||'')+' '+f.lowPrice+(f.highPrice?' - '+f.highPrice:''));
   else if(f&&f.price)r.priceLines.unshift((f.priceCurrency||'')+' '+f.price);}}});}catch(x){}});
var seen={};
document.querySelectorAll('img').forEach(function(i){
 var s=i.currentSrc||i.getAttribute('data-src')||i.getAttribute('data-lazy-src')||i.src||'';
 if(s.indexOf('//')==0)s='https:'+s;
 if(s.indexOf('http')!=0||seen[s]||r.images.length>=70)return;
 var w=i.naturalWidth||i.width||0;
 if(w>0&&w<100)return;
 if(/logo|icon|sprite|avatar|flag|badge|\.gif|\.svg/i.test(s)&&w<300)return;
 seen[s]=1;
 var tag='detail';
 if(i.closest('[class*=cert],[class*=Cert]'))tag='cert';
 else if(i.closest('[class*=company],[class*=Company],[class*=factory],[class*=Factory],[class*=profile],[class*=Profile]'))tag='company';
 else if(i.closest('[class*=gallery],[class*=Gallery],[class*=slider],[class*=Slider],[class*=thumb],[class*=Thumb],[class*=preview],[class*=main-image],[class*=magnifier]'))tag='gallery';
 r.images.push([s,tag]);});
var kw=/(verified|audited|years|yrs|manufacturer|trading company|factory|established|employees|staff|response|on-time|certif|ISO ?\d|RoHS|FCC|lead time|sample|customi|OEM|ODM|supply ability|main products|export|capacity|warranty|payment|located|province|min\.? order|minimum order|moq|trade assurance|shipping|tax|floor area|annual revenue|registered capital|legal rep|business license)/i;
body.split('\n').forEach(function(l){l=l.trim();if(l.length>3&&l.length<170){
 if(kw.test(l)&&r.facts.length<160)r.facts.push(l);
 if(!r.supplier&&/(co\.?,?\s?ltd|limited|factory)/i.test(l)&&l.length<100&&!/\d{3,}/.test(l))r.supplier=l;}});
var prof=/company_profile|minisite|\.en\.alibaba\.com|\/supplier|showroom|\.en\.made-in-china\.com|shop\d*\.1688|winport/i;
var seenL={};
document.querySelectorAll('a[href]').forEach(function(a){
 var h=(a.href||'').split('#')[0];
 if(!/^https?:/.test(h)||seenL[h]||/product-detail|\/product\//.test(h)||h===location.href.split('#')[0])return;
 var t=T(a).slice(0,70);
 if(prof.test(h)||/certificate|company website|official website|company profile/i.test(t)){
  seenL[h]=1;if(r.links.length<20)r.links.push([t,h]);
  if(!r.supplier&&prof.test(h)&&/(co\.?,?\s?ltd|limited|company|factory|technology|trading|industr|manufactur|inc\b)/i.test(t)&&t.length<90)r.supplier=t;}});
var pe=document.querySelectorAll('[class*=price],[class*=Price]');
for(var p=0;p<pe.length&&r.priceLines.length<40;p++){(pe[p].innerText||'').split('\n').forEach(function(l){l=l.trim();if(l&&l.length<80&&/\d/.test(l))r.priceLines.push(l);});}
body.split('\n').forEach(function(l){l=l.trim();if(l.length<80&&/(US\x24|\x24|¥|₹|€|£|Rs\.?|USD|RMB|CNY|INR)\s?\d/.test(l)&&r.priceLines.length<60)r.priceLines.push(l);});
return JSON.stringify(r);
})()"""

const val SCROLL_JS = """(function(){var n=0;var t=setInterval(function(){window.scrollBy(0,800);n++;if(n>14){clearInterval(t);window.scrollTo(0,0);}},300);return 'ok';})()"""
