package com.chinaresearch

import org.json.JSONArray
import org.json.JSONObject

const val NF = "Information Not Found"

data class Requirement(val name: String, val maxPrice: Double?, val currency: String, val maxMoq: Int?, val specs: List<Pair<String, String>>, val notes: String)
data class Fact(val label: String, val value: String, val source: String)
data class Supplier(val name: String?, val url: String?, val facts: List<Fact> = emptyList(), val images: List<String> = emptyList(), val badges: List<String> = emptyList(), val profileLoaded: Boolean = false)
data class Product(
    val title: String, val url: String, val image: String?, val platform: String,
    val priceText: String?, val minPrice: Double?, val maxPriceFound: Double?, val currency: String?,
    val moqText: String?, val moq: Int?,
    val priceLines: List<String> = emptyList(), val images: List<String> = emptyList(),
    val attrs: List<Pair<String, String>> = emptyList(), val pageText: String = "",
    val supplier: Supplier? = null, val detailLoaded: Boolean = false
)

enum class Status(val label: String) {
    MATCH("✅ Match"), NO("❌ Doesn't Match"), PARTIAL("⚠️ Partial / Unclear"), NA("— Information Unavailable")
}
data class Row(val param: String, val required: String, val found: String, val status: Status, val source: String)

private const val CUR = "US\\$|CN¥|¥|₹|Rs\\.?|INR|\\$|€|RMB"
private val priceRx = Regex("($CUR)\\s?([\\d,]+(?:\\.\\d+)?)(?:\\s?[-–~]\\s?(?:$CUR)?\\s?([\\d,]+(?:\\.\\d+)?))?")
private val moqRx = Regex("(?:Min\\.?\\s*order:?\\s*([\\d,]+))|(?:([\\d,]+)\\s*[A-Za-z]*\\s*\\(MOQ\\))|(?:MOQ:?\\s*([\\d,]+))", RegexOption.IGNORE_CASE)
private fun num(s: String?) = s?.replace(",", "")?.toDoubleOrNull()
fun normCur(s: String) = when {
    s.contains("US") || s == "\$" -> "USD"; s.contains("¥") || s == "RMB" -> "CNY"
    s.contains("₹") || s.startsWith("Rs") || s == "INR" -> "INR"; s == "€" -> "EUR"; else -> s
}
private fun JSONArray?.strs(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }
private fun moqOf(t: String) = moqRx.find(t)?.let { m -> m to num(m.groupValues.drop(1).firstOrNull { it.isNotBlank() })?.toInt() }

fun parseProducts(json: String, platform: String): List<Product> {
    val arr = JSONArray(json)
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i); val text = o.optString("text")
        val p = priceRx.find(text); val mo = moqOf(text)
        val lines = text.lines().map { it.trim() }.filter { it.length > 3 }
        Product(lines.take(5).maxByOrNull { it.length } ?: NF, o.optString("url"), o.optString("img").ifBlank { null }, platform,
            p?.value, num(p?.groupValues?.get(2)), num(p?.groupValues?.get(3)), p?.let { normCur(it.groupValues[1]) },
            mo?.first?.value, mo?.second)
    }.filter { it.url.isNotBlank() }.distinctBy { it.url }
}

private val factKeys = listOf(
    "Established" to "Year established|Established|Founded|Total years",
    "Employees" to "Total employees|Number of employees|Employees",
    "Location" to "Location|Registered address|Address|Country/Region",
    "Business type" to "Business type|Company type",
    "Main products" to "Main products",
    "Annual revenue" to "Total annual revenue|Annual revenue",
    "Factory size" to "Factory size|Floor space|Plant area",
    "Certifications" to "Certifications?",
    "Response time" to "Avg\\.? response time|Response time",
    "On-time delivery" to "On-time delivery rate",
    "Export markets" to "Main markets|Export countries",
    "Registered capital" to "Registered capital"
)
fun extractFacts(text: String, source: String) = factKeys.mapNotNull { (label, pat) ->
    Regex("(?i)(?:$pat)[ \\t]*[:：]?[ \\t]*\\n?[ \\t]*([^\\n]{2,100})").find(text)?.let { Fact(label, it.groupValues[1].trim(), source) }
}
private fun badges(t: String) = listOf("Verified", "Trade Assurance", "Gold Supplier", "Audited Supplier", "Assessed Supplier", "Verified Pro").filter { t.contains(it, true) }

fun applyDetail(p: Product, json: String): Product {
    val o = JSONObject(json); val t = o.optString("text")
    val pl = t.lines().map { it.trim() }.filter { priceRx.containsMatchIn(it) && it.length < 80 }.distinct().take(6)
    val pm = priceRx.find(pl.firstOrNull() ?: "")
    val mo = moqOf(t)
    val attrs = o.optJSONArray("attrs")?.let { a -> (0 until a.length()).mapNotNull {
        val r = a.getJSONArray(it); val k = r.optString(0); val v = r.optString(1)
        if (k.isNotBlank() && v.isNotBlank() && k.length < 60) k to v else null } }?.distinct() ?: emptyList()
    val imgs = (listOfNotNull(p.image) + o.optJSONArray("imgs").strs()).filter { !it.contains(".svg") && !it.contains("logo", true) }.distinct()
    return p.copy(
        title = if (p.title == NF) o.optString("title").ifBlank { NF } else p.title,
        priceText = p.priceText ?: pm?.value, minPrice = p.minPrice ?: num(pm?.groupValues?.get(2)),
        maxPriceFound = p.maxPriceFound ?: num(pm?.groupValues?.get(3)), currency = p.currency ?: pm?.let { normCur(it.groupValues[1]) },
        moqText = p.moqText ?: mo?.first?.value, moq = p.moq ?: mo?.second,
        priceLines = pl, images = imgs, attrs = attrs, pageText = t, detailLoaded = true,
        supplier = Supplier(o.optString("supName").ifBlank { null }, o.optString("supUrl").ifBlank { null }, extractFacts(t, "Product page"), emptyList(), badges(t))
    )
}

fun applySupplier(p: Product, json: String): Product {
    val o = JSONObject(json); val t = o.optString("text"); val s = p.supplier ?: Supplier(null, null)
    val facts = (s.facts.filter { f -> extractFacts(t, "").none { it.label == f.label } } + extractFacts(t, "Supplier profile page"))
    return p.copy(supplier = s.copy(name = s.name ?: o.optString("title").ifBlank { null }, facts = facts,
        images = o.optJSONArray("imgs").strs().filter { !it.contains(".svg") }.distinct(), badges = (s.badges + badges(t)).distinct(), profileLoaded = true))
}

private fun norm(s: String) = s.lowercase().replace(Regex("\\s"), "")

/** Conservative rule-based matching. Incomplete info is never auto-matched; certifications are never "verified". */
fun matchProduct(r: Requirement, p: Product): List<Row> {
    val rows = mutableListOf<Row>()
    r.maxPrice?.let { max ->
        val st = when {
            p.minPrice == null -> Status.NA
            p.currency != null && p.currency != r.currency -> Status.PARTIAL
            p.minPrice > max -> Status.NO
            p.maxPriceFound != null && p.maxPriceFound > max -> Status.PARTIAL
            p.maxPriceFound != null -> Status.MATCH
            else -> Status.PARTIAL
        }
        val note = if (p.currency != null && p.currency != r.currency) " (listing currency ${p.currency})" else ""
        rows += Row("Price", "≤ $max ${r.currency}", (p.priceText ?: NF) + note, st, "Listing")
    }
    r.maxMoq?.let { max ->
        rows += Row("MOQ", "≤ $max", p.moqText ?: NF, when { p.moq == null -> Status.NA; p.moq <= max -> Status.MATCH; else -> Status.NO }, "Listing")
    }
    for ((k, v) in r.specs) {
        val hit = p.attrs.firstOrNull { it.first.contains(k, true) }
        var row = when {
            hit != null -> Row(k, v, hit.second, if (norm(hit.second).contains(norm(v))) Status.MATCH else Status.PARTIAL, "Product attributes")
            p.pageText.contains(v, true) || p.title.contains(v, true) -> Row(k, v, "Mentioned in page text only", Status.PARTIAL, "Page text")
            else -> Row(k, v, NF, Status.NA, "-")
        }
        if (k.contains("cert", true) && row.status == Status.MATCH) row = row.copy(status = Status.PARTIAL, found = row.found + " (supplier claim)")
        rows += row
    }
    return rows
}

fun verification(p: Product): List<Fact> {
    val t = p.pageText; val s = p.supplier
    return listOf(
        Fact("Manufacturer status", if (listOf("manufacturer", "factory").any { t.contains(it, true) }) "⚠️ Supplier claim, not independently confirmed" else "— Not stated", "Platform page"),
        Fact("Platform badges", if (s?.badges.isNullOrEmpty()) "None found" else s!!.badges.joinToString() + " (shown by platform; not independent evidence)", "Platform page"),
        Fact("Company registration", "Not Verified (registry not checked)", "-"),
        Fact("Certifications", if (t.contains("certif", true)) "⚠️ Supplier claim only" else "Not found", "Platform page")
    )
}

fun warnings(p: Product): List<String> {
    val w = mutableListOf<String>(); val s = p.supplier
    if (!p.detailLoaded) w += "⚠ Product detail page could not be read."
    if (p.priceText == null) w += "⚠ Price not found."
    if (p.moq == null) w += "⚠ MOQ not found."
    if (s?.profileLoaded != true) w += "⚠ Supplier profile page not read."
    w += "⚠ Manufacturer status and certificates are not independently confirmed."
    if (p.attrs.isNotEmpty()) w += "✓ Product specifications available (${p.attrs.size} fields)."
    return w
}

fun missing(p: Product): List<String> {
    val s = p.supplier; val m = mutableListOf<String>()
    if (p.priceText == null) m += "Price"; if (p.moq == null) m += "MOQ"
    if (p.attrs.isEmpty()) m += "Specifications"
    if (s?.name == null) m += "Supplier name"; if (s?.url == null) m += "Supplier profile link"
    listOf("Location", "Established", "Employees", "Certifications").forEach { l -> if (s?.facts?.none { it.label == l } != false) m += l }
    m += listOf("Registration number", "Legal representative", "Independent factory evidence")
    return m
}

fun reportText(r: Requirement, p: Product): String = buildString {
    appendLine("CHINA SUPPLIER RESEARCH: ${p.title}")
    appendLine("Platform: ${p.platform}\nPrice: ${p.priceText ?: NF}\nMOQ: ${p.moqText ?: NF}")
    appendLine("Supplier: ${p.supplier?.name ?: NF}")
    p.supplier?.facts?.forEach { appendLine("${it.label}: ${it.value} [${it.source}]") }
    appendLine("\nMatching:"); matchProduct(r, p).forEach { appendLine("${it.param} | ${it.required} | ${it.found} | ${it.status.label}") }
    appendLine("\nVerification:"); verification(p).forEach { appendLine("${it.label}: ${it.value}") }
    appendLine("\nSource: ${p.url}"); p.supplier?.url?.let { appendLine("Supplier: $it") }
}
