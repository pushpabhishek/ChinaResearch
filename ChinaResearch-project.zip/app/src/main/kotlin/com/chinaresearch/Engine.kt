package com.chinaresearch

import org.json.JSONArray

data class Requirement(val name: String, val maxPrice: Double?, val maxMoq: Int?, val material: String, val notes: String)

data class Product(
    val title: String, val url: String, val image: String?, val platform: String,
    val priceText: String?, val minPrice: Double?, val maxPriceFound: Double?,
    val moqText: String?, val moq: Int?
)

enum class Status(val label: String) {
    MATCH("✅ Match"), NO("❌ Doesn't Match"), PARTIAL("⚠️ Partial / Unclear"), NA("— Information Unavailable")
}

data class Row(val param: String, val required: String, val found: String, val status: Status)

private val priceRx = Regex("""(?:US\$|\$|¥|RMB)\s?([\d,]+(?:\.\d+)?)(?:\s?-\s?(?:US\$|\$|¥|RMB)?\s?([\d,]+(?:\.\d+)?))?""")
private val moqRx = Regex("""(?:Min\.?\s*order:?\s*([\d,]+))|(?:([\d,]+)\s*[A-Za-z]*\s*\(MOQ\))""", RegexOption.IGNORE_CASE)
private fun num(s: String?) = s?.replace(",", "")?.toDoubleOrNull()

/** Parses the JSON array produced by the page-extraction script. Nothing is invented: missing = null. */
fun parseProducts(json: String, platform: String): List<Product> {
    val arr = JSONArray(json)
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val text = o.optString("text")
        val p = priceRx.find(text)
        val m = moqRx.find(text)
        val lines = text.lines().map { it.trim() }.filter { it.length > 3 }
        Product(
            title = lines.firstOrNull() ?: "Information Not Found",
            url = o.optString("url"), image = o.optString("img").ifBlank { null }, platform = platform,
            priceText = p?.value, minPrice = num(p?.groupValues?.get(1)),
            maxPriceFound = num(p?.groupValues?.get(2)),
            moqText = m?.value, moq = (num(m?.groupValues?.get(1)) ?: num(m?.groupValues?.get(2)))?.toInt()
        )
    }.filter { it.url.isNotBlank() }.distinctBy { it.url }
}

/** Rule-based matching. Incomplete info is never auto-matched. */
fun matchProduct(r: Requirement, p: Product): List<Row> {
    val rows = mutableListOf<Row>()
    r.maxPrice?.let { max ->
        val found = p.priceText ?: "Information Not Found"
        val st = when {
            p.minPrice == null -> Status.NA
            p.minPrice > max -> Status.NO
            p.maxPriceFound != null && p.maxPriceFound <= max -> Status.MATCH
            else -> Status.PARTIAL // range/starting price: upper bound or quantity basis unknown
        }
        rows += Row("Price", "≤ $max", found, st)
    }
    r.maxMoq?.let { max ->
        val st = when { p.moq == null -> Status.NA; p.moq <= max -> Status.MATCH; else -> Status.NO }
        rows += Row("MOQ", "≤ $max", p.moqText ?: "Information Not Found", st)
    }
    if (r.material.isNotBlank()) {
        val hit = p.title.contains(r.material, ignoreCase = true)
        rows += Row("Material", r.material, if (hit) "Found in title" else "Not stated in listing",
            if (hit) Status.PARTIAL else Status.NA) // title mention = claim only
    }
    return rows
}
