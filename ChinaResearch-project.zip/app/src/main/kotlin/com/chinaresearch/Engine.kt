package com.chinaresearch

import org.json.JSONArray
import org.json.JSONObject

object Rates { @Volatile var inr = 0.0; @Volatile var cny = 0.0 }

fun toUsd(cur: String?, v: Double): Double? = when (cur) {
    "USD" -> v
    "INR" -> if (Rates.inr > 0) v / Rates.inr else null
    "CNY" -> if (Rates.cny > 0) v / Rates.cny else null
    else -> null
}

private const val CUR = """US\s?\$|USD|\$|¥|RMB|CNY|₹|INR|Rs\.?|€|£|EUR|GBP"""
private val priceRx = Regex("""(?<![A-Za-z])($CUR)\s?([\d,]+(?:\.\d+)?)(?:\s?(?:-|–|~|to)\s?(?:$CUR)?\s?([\d,]+(?:\.\d+)?))?""", RegexOption.IGNORE_CASE)
private val priceRx2 = Regex("""(?<![\w.])([\d,]+(?:\.\d+)?)\s?(USD|CNY|RMB|INR|EUR)\b""", RegexOption.IGNORE_CASE)
private val moqRx = Regex(
    """(?:Min\.?(?:imum)?\s*order(?:\s*quantity)?\s*:?\s*([\d,]+)(?:\s*[A-Za-z]+)?)|(?:MOQ\s*:?\s*([\d,]+))|(?:([\d,]+)\s*[A-Za-z]*\s*\(MOQ\))""",
    RegexOption.IGNORE_CASE
)
private val numRx = Regex("""\d+(?:\.\d+)?""")
private val cjk = Regex("[\\u4e00-\\u9fff]")
private val supplierRx = Regex("""(Co\.?,?\s?Ltd|Limited|Factory|Company|Technology|Trading|Industr|Manufactur|Inc\b)""", RegexOption.IGNORE_CASE)
private val provRx = Regex(
    """\b(Guangdong|Zhejiang|Jiangsu|Shandong|Fujian|Hebei|Henan|Shanghai|Beijing|Sichuan|Hubei|Hunan|Anhui|Liaoning|Tianjin|Chongqing|Shaanxi|Jiangxi|Guangxi|Yunnan|Shanxi|Jilin|Heilongjiang|Hainan|Guizhou|Gansu|Xinjiang|Shenzhen|Guangzhou|Dongguan|Ningbo|Hangzhou|Yiwu|Foshan|Suzhou)\b[^|\n]{0,40}""",
    RegexOption.IGNORE_CASE
)

private fun num(s: String?): Double? = s?.replace(",", "")?.toDoubleOrNull()

fun normCur(s: String?): String? {
    if (s == null || s.isBlank()) return null
    val t = s.uppercase().replace(" ", "").replace(".", "")
    return when {
        t.startsWith("US") || t == "\$" -> "USD"
        t == "¥" || t == "RMB" -> "CNY"
        t == "₹" || t == "RS" -> "INR"
        t == "€" -> "EUR"
        t == "£" -> "GBP"
        else -> t
    }
}

data class PriceHit(val text: String, val cur: String?, val lo: Double?, val hi: Double?)

fun findPrice(text: String): PriceHit? {
    val m = priceRx.find(text)
    if (m != null) return PriceHit(m.value.trim(), normCur(m.groupValues[1]), num(m.groupValues[2]), num(m.groupValues[3]))
    val m2 = priceRx2.find(text)
    if (m2 != null) return PriceHit(m2.value.trim(), normCur(m2.groupValues[2]), num(m2.groupValues[1]), null)
    return null
}

fun normImg(u: String): String {
    var s = u.trim()
    if (s.startsWith("//")) s = "https:$s"
    return Regex("""(\.(?:jpe?g|png|webp))_\d+x\d+[^/]*${'$'}""", RegexOption.IGNORE_CASE).replace(s, "\$1")
}

// ---------- parsing ----------
data class SearchResult(val blocked: Boolean, val items: List<Product>)

fun parseSearch(json: String, platform: String): SearchResult {
    val root = JSONObject(json)
    val arr = root.optJSONArray("items") ?: JSONArray()
    val items = (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val text = o.optString("text")
        val lines = text.lines().map { it.trim() }.filter { it.length in 2..140 }.distinct().take(30)
        val pr = findPrice(text)
        val m = moqRx.find(text)
        val rawTitle = o.optString("title").replace(Regex("\\s+"), " ").trim()
        val title = rawTitle.ifBlank { lines.firstOrNull { it.length > 12 && findPrice(it) == null } ?: lines.firstOrNull() ?: NF }
        val moqNum = m?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() }
        Product(
            title = title, url = o.optString("url"), image = o.optString("img").ifBlank { null }?.let { normImg(it) },
            platform = platform, priceText = pr?.text, currency = pr?.cur, minPrice = pr?.lo, maxPriceFound = pr?.hi,
            moqText = m?.value?.trim(), moq = num(moqNum)?.toInt(),
            supplier = lines.firstOrNull { it != title && it.length < 100 && supplierRx.containsMatchIn(it) },
            card = lines
        )
    }.filter { it.url.isNotBlank() }.distinctBy { it.url }
    return SearchResult(root.optBoolean("blocked"), items)
}

fun supplierProfileUrl(links: List<Pair<String, String>>): String? {
    val l = links.map { it.second }
    val u = l.firstOrNull { it.contains("company_profile") } ?: l.firstOrNull { it.contains("minisite") || it.contains(".en.alibaba.com") }
        ?: l.firstOrNull { it.contains("showroom") || it.contains("supplier") || it.contains("made-in-china.com") || it.contains("1688.com") }
        ?: return null
    val host = Regex("""^https?://([^/]+)""").find(u)?.groupValues?.get(1) ?: return u
    return if (host.endsWith(".en.alibaba.com") && !u.contains("company_profile")) "https://$host/company_profile.html" else u
}

fun parsePage(json: String, url: String): PageData {
    val o = JSONObject(json)
    val links = o.getJSONArray("links").pairs().distinctBy { it.second }
    return PageData(
        url = url, title = o.optString("title"), desc = o.optString("desc"),
        specs = o.getJSONArray("specs").pairs().distinct().take(300),
        images = o.getJSONArray("images").pairs().map { normImg(it.first) to it.second }.distinctBy { it.first }.take(60),
        facts = o.getJSONArray("facts").strs().distinct(), links = links,
        supplierName = o.optString("supplier").ifBlank { null }, supplierUrl = supplierProfileUrl(links),
        priceLines = o.getJSONArray("priceLines").strs().distinct().take(40), blocked = o.optBoolean("blocked"), bodyLen = o.optInt("bodyLen")
    )
}

// ---------- lookups ----------
fun List<Pair<String, String>>.find2(vararg keys: String): String? {
    for (k in keys) { val h = firstOrNull { it.first.equals(k, true) }; if (h != null) return h.second }
    for (k in keys) { val h = firstOrNull { it.first.contains(k, true) }; if (h != null) return h.second }
    return null
}

private fun allLines(p: Product, d: PageData?, sup: PageData?): List<String> =
    (p.card + d?.facts.orEmpty() + sup?.facts.orEmpty() +
        d?.specs.orEmpty().map { it.first + ": " + it.second } + sup?.specs.orEmpty().map { it.first + ": " + it.second }).distinct()

// ---------- price / moq ----------
data class PriceInfo(val text: String?, val cur: String?, val lo: Double?, val hi: Double?, val kind: String, val tiers: List<String>, val source: String)

fun tierLines(d: PageData?): List<String> {
    val out = mutableListOf<String>()
    var pend: String? = null
    val qtyRx = Regex("""(\d[\d,]*\s*[-–]\s*\d[\d,]*|[≥>]=?\s*\d[\d,]*|\d[\d,]*\s*\+)\s*([A-Za-z]+)?""")
    for (l in d?.priceLines.orEmpty()) {
        val pr = findPrice(l)
        if (pr != null) {
            val q = qtyRx.find(l.replace(pr.text, " "))
            if (q != null) { out += q.value.trim() + " → " + pr.text; pend = null }
            else if (pend != null) { out += pend + " → " + pr.text; pend = null }
        } else if (l.length < 40 && qtyRx.containsMatchIn(l)) pend = l
    }
    return out.distinct().take(8)
}

fun priceInfo(p: Product, d: PageData?): PriceInfo {
    val tiers = tierLines(d)
    val listing = p.priceText != null
    val hit = if (listing) PriceHit(p.priceText!!, normCur(p.currency), p.minPrice, p.maxPriceFound)
    else d?.priceLines?.firstNotNullOfOrNull { findPrice(it) }
    if (hit == null) return PriceInfo(null, null, null, null, "Price", tiers, "")
    val ctx = (p.card + d?.priceLines.orEmpty()).firstOrNull { it.contains(hit.text) } ?: ""
    val kind = when {
        Regex("from|starting|start", RegexOption.IGNORE_CASE).containsMatchIn(ctx) -> "Starting price"
        hit.hi != null -> "Price range"
        else -> "Unit price"
    }
    return PriceInfo(hit.text, hit.cur, hit.lo, hit.hi, kind, tiers, if (listing) "Search listing" else "Product page")
}

fun moqOf(p: Product, d: PageData?): Pair<Int?, String?> {
    if (p.moqText != null) return p.moq to p.moqText
    val s = d?.specs?.find2("minimum order", "min. order", "min order", "moq")
    if (s != null) return num(numRx.find(s.replace(",", ""))?.value)?.toInt() to s
    val m = moqRx.find((d?.facts.orEmpty() + d?.priceLines.orEmpty()).joinToString("\n"))
    if (m != null) {
        val n = m.groupValues.drop(1).firstOrNull { it.isNotEmpty() }
        return num(n)?.toInt() to m.value.trim()
    }
    val t = tierLines(d).firstOrNull()
    if (t != null) {
        val n = Regex("""(\d[\d,]*)""").find(t)?.value
        return num(n)?.toInt() to ("From first price tier: " + t.substringBefore(" →"))
    }
    return null to null
}

// ---------- comparison of one value ----------
fun compareValue(req: String, found: String): Status {
    val rq = req.replace(" ", "").lowercase()
    val fd = found.replace(" ", "").lowercase()
    if (rq.isEmpty()) return Status.NA
    if (fd.contains(rq)) return Status.MATCH
    val rn = numRx.find(req.replace(",", ""))?.value?.toDoubleOrNull() ?: return Status.PARTIAL
    val nums = numRx.findAll(found.replace(",", "")).mapNotNull { it.value.toDoubleOrNull() }.toList()
    if (nums.isEmpty()) return Status.PARTIAL
    val ru = req.filter { it.isLetter() }.lowercase()
    val fu = found.filter { it.isLetter() }.lowercase()
    if (ru.isNotEmpty() && fu.isNotEmpty() && !fu.contains(ru.take(1))) return Status.PARTIAL
    val ge = req.contains("≥") || req.contains(">") || req.trimStart().startsWith("min", true)
    val le = req.contains("≤") || req.contains("<") || req.trimStart().startsWith("max", true)
    val range = nums.size >= 2 && Regex("""\d\s*(?:-|–|~|to)\s*\d""").containsMatchIn(found)
    val hi = nums.maxOrNull() ?: rn
    val lo = nums.minOrNull() ?: rn
    val ok = when {
        ge -> hi >= rn
        le -> lo <= rn
        range -> rn >= lo && rn <= hi
        else -> nums.any { it == rn }
    }
    return if (ok) Status.MATCH else Status.NO
}

// ---------- location ----------
fun supplierLocation(p: Product, d: PageData?, sup: PageData?): String? {
    for (x in listOfNotNull(sup, d)) {
        val v = x.specs.find2("location", "address", "province", "registered address")
        if (v != null) return v
    }
    val lines = sup?.facts.orEmpty() + d?.facts.orEmpty() + p.card
    for (l in lines) { val m = provRx.find(l); if (m != null) return m.value.trim() }
    return p.card.firstOrNull { Regex("""\bCN\b|China""").containsMatchIn(it) && it.length < 40 }
}

// ---------- matching ----------
fun matchProduct(r: Requirement, p: Product, d: PageData?, sup: PageData? = null): List<Row> {
    val rows = mutableListOf<Row>()
    val specs = d?.specs.orEmpty()
    val hay = (listOf(p.title, d?.title ?: "", d?.desc ?: "") + p.card + specs.map { it.first + " " + it.second } + d?.facts.orEmpty()).joinToString(" | ")
    val pi = priceInfo(p, d)

    if (r.maxPrice != null) {
        val max = r.maxPrice
        val pc = pi.cur; val rc = normCur(r.currency)
        val conv = pi.lo != null && pc != rc
        val lu = if (conv) toUsd(pc, pi.lo!!) else null
        val ru = if (conv) toUsd(rc, max) else null
        val comparable = !conv || (lu != null && ru != null)
        val lo = if (conv && comparable) lu else pi.lo
        val hi = if (conv && comparable) pi.hi?.let { toUsd(pc, it) } else pi.hi
        val mx = if (conv && comparable) ru!! else max
        val st = when {
            lo == null -> Status.NA
            !comparable -> Status.PARTIAL
            lo > mx -> Status.NO
            hi != null && hi > mx -> Status.PARTIAL
            pi.kind == "Starting price" -> Status.PARTIAL
            else -> Status.MATCH
        }
        val note = if (!conv || pi.lo == null) "" else if (comparable) " (converted using your rates)" else " (currency differs: set rates in Settings)"
        rows += Row("Price", "≤ $max ${r.currency}", (pi.text ?: NF) + note + (if (pi.text != null) " [${pi.kind}]" else ""), st, pi.source.ifBlank { "Listing" })
    }
    if (r.maxMoq != null) {
        val (n, t) = moqOf(p, d)
        val st = when { n == null -> Status.NA; n <= r.maxMoq -> Status.MATCH; else -> Status.NO }
        rows += Row("MOQ", "≤ ${r.maxMoq}", t ?: NF, st, if (p.moqText != null) "Search listing" else "Product page")
    }
    fun add(label: String, req: String, vararg keys: String) {
        if (req.isBlank()) return
        val hit = specs.find2(*keys)
        if (hit != null) rows += Row(label, req, hit, compareValue(req, hit), "Product specifications")
        else if (hay.contains(req, true)) rows += Row(label, req, "Mentioned on page (no matching spec field)", Status.PARTIAL, "Product page")
        else rows += Row(label, req, NF, Status.NA, "Product page")
    }
    add("Material", r.material, "material")
    add("Size / Dimension", r.size, "size", "dimension")
    add("Capacity", r.capacity, "capacity", "volume", "flow")
    add("Voltage", r.voltage, "voltage")
    add("Power", r.power, "power", "wattage")
    add("Performance", r.performance, "performance", "speed", "efficiency", "output")
    add("Customization", r.customization, "customiz", "oem", "odm", "logo")
    if (r.certification.isNotBlank()) {
        val hit = specs.find2("certification", "certificate")
        val any = hit != null || hay.contains(r.certification, true)
        val has = hit?.contains(r.certification, true) == true || hay.contains(r.certification, true)
        rows += Row("Certification", r.certification, if (has) "Mentioned (supplier claim, not verified)" else hit ?: NF,
            if (has) Status.PARTIAL else if (any) Status.PARTIAL else Status.NA, "Product page")
    }
    if (r.country.isNotBlank()) {
        val loc = supplierLocation(p, d, sup)
        val chinaish = r.country.contains("china", true) || r.country.equals("cn", true)
        val st = when {
            loc != null && loc.contains(r.country, true) -> Status.MATCH
            loc != null && chinaish && (provRx.containsMatchIn(loc) || loc.contains("china", true) || loc.contains("CN")) -> Status.MATCH
            loc != null -> Status.PARTIAL
            hay.contains(r.country, true) -> Status.PARTIAL
            else -> Status.NA
        }
        rows += Row("Country / Region", r.country, loc ?: (if (st == Status.PARTIAL) "Mentioned on page" else NF), st, "Listing / profile")
    }
    r.specs.forEach { (k, v) -> add(k, v, k) }
    return rows
}

// ---------- fields ----------
fun productFields(p: Product, d: PageData?): List<Field> {
    val s = d?.specs.orEmpty()
    fun f(label: String, vararg keys: String) = Field(label, s.find2(*keys), "Product page")
    val pi = priceInfo(p, d)
    val moq = moqOf(p, d)
    val chinese = (listOf(p.title, d?.title ?: "") + p.card).firstOrNull { cjk.containsMatchIn(it) }
    return listOf(
        Field("Product name", p.title, p.platform),
        Field("Chinese name", chinese, p.platform),
        f("Model number", "model number", "model no", "item model", "model", "item no", "part number", "sku"),
        f("Brand", "brand"),
        f("Place of origin", "place of origin", "origin"),
        Field("Description", d?.desc?.ifBlank { null }, "Product page"),
        f("Material", "material"),
        f("Size / Dimension", "product size", "dimension", "size"),
        f("Weight", "net weight", "weight"),
        f("Capacity", "capacity", "volume"),
        f("Voltage", "voltage"),
        f("Power", "power", "wattage"),
        f("Performance", "performance", "speed", "efficiency"),
        f("Variants / Colour", "colour", "color", "variant", "style"),
        f("Packaging", "packaging", "package", "packing"),
        f("Lead time", "lead time", "delivery time"),
        f("Customization", "customiz", "oem", "odm", "logo"),
        f("Sample", "sample"),
        f("Warranty", "warranty"),
        f("Certification", "certification", "certificate"),
        Field(pi.kind, pi.text, pi.source),
        Field("Currency", pi.cur, pi.source),
        Field("MOQ", moq.second, if (p.moqText != null) "Search listing" else "Product page")
    )
}

fun supplierFields(p: Product, d: PageData?, sup: PageData?): List<Field> {
    fun g(label: String, vararg keys: String): Field {
        val a = sup?.specs?.find2(*keys)
        if (a != null) return Field(label, a, "Supplier profile")
        val b = d?.specs?.find2(*keys)
        if (b != null) return Field(label, b, "Product page")
        return Field(label, null, "")
    }
    val lines = allLines(p, d, sup)
    val name = sup?.supplierName ?: d?.supplierName ?: p.supplier
    val chinese = listOfNotNull(name, sup?.title, d?.supplierName).firstOrNull { cjk.containsMatchIn(it) }
    val est = g("Established", "year established", "established", "founded", "registration date", "establishment")
    val estYear = est.value?.let { Regex("""(19|20)\d{2}""").find(it)?.value?.toIntOrNull() }
    val yrs = lines.firstNotNullOfOrNull { Regex("""(\d+)\s*(?:yrs|years|yr)\b""", RegexOption.IGNORE_CASE).find(it)?.value }
    val thisYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
    val age = when {
        estYear != null -> Field("Company age", "About ${thisYear - estYear} years (calculated from $estYear)", est.source)
        yrs != null -> Field("Company age", "$yrs (as shown by platform)", "Listing / profile")
        else -> Field("Company age", null)
    }
    val bt = g("Business type", "business type", "company type", "type of business")
    val btxt = (listOfNotNull(bt.value) + lines).joinToString(" | ")
    val mfr = when {
        Regex("manufactur|factory", RegexOption.IGNORE_CASE).containsMatchIn(btxt) -> "Page mentions manufacturer / factory (supplier claim, not independently confirmed)"
        Regex("trading", RegexOption.IGNORE_CASE).containsMatchIn(btxt) -> "Page mentions trading company (supplier claim)"
        else -> null
    }
    val website = sup?.links?.firstOrNull { it.first.contains("website", true) }?.second ?: d?.links?.firstOrNull { it.first.contains("website", true) }?.second
    val certs = certRows(p, d, sup).map { it.name }.distinct()
    return listOf(
        Field("Company name", name, if (sup?.supplierName != null) "Supplier profile" else if (d?.supplierName != null) "Product page" else "Search listing"),
        Field("Chinese name", chinese, "Page"),
        Field("Platform", p.platform, p.platform),
        Field("Profile URL", sup?.url ?: d?.supplierUrl, "Product page"),
        Field("Website", website ?: g("Website", "website").value, "Profile"),
        Field("Location", supplierLocation(p, d, sup), "Listing / profile"),
        est, age,
        g("Legal representative", "legal representative", "legal person", "法人"),
        g("Registered capital", "registered capital", "注册资本"),
        g("Registration no.", "registration number", "business license", "unified social credit", "registration no"),
        bt, Field("Mfr / trading indication", mfr, "Page text"),
        g("Business status", "business status", "operating status"),
        g("Main products / scope", "main products", "business scope", "main product"),
        g("Production capability", "production capacity", "supply ability", "production line", "annual output", "capacity"),
        g("Export information", "export", "main markets", "main export"),
        g("Employees", "total employees", "employees", "number of staff", "staff"),
        g("Factory size", "floor area", "factory size", "plant area", "factory area"),
        g("Annual revenue", "annual revenue", "total annual revenue", "annual sales"),
        g("Response rate / time", "response rate", "avg. response", "response time"),
        g("On-time delivery", "on-time delivery", "on time delivery"),
        Field("Certifications", if (certs.isEmpty()) null else certs.joinToString(", "), "Page text (claims)")
    )
}

// ---------- verification ----------
data class CertRow(val name: String, val number: String?, val issuer: String?, val expiry: String?, val status: String, val source: String)
data class Conflict(val field: String, val a: String, val aSrc: String, val b: String, val bSrc: String)
data class Verif(val evidence: List<String>, val claims: List<String>, val notVerified: List<String>)

private val certNameRx = Regex("""\b(ISO\s?\d{4,5}|CE|RoHS|FCC|UL|ETL|FDA|REACH|BSCI|SGS|TUV|TÜV|GMP|HACCP|CCC|IATF\s?16949|SAA|PSE|KC|GS)\b""")

fun certRows(p: Product, d: PageData?, sup: PageData?): List<CertRow> {
    val out = LinkedHashMap<String, CertRow>()
    for (l in allLines(p, d, sup) + listOf(p.title)) {
        for (m in certNameRx.findAll(l)) {
            val name = m.value.replace(Regex("\\s+"), " ")
            val number = Regex("""(?:No\.?|Number|#)\s*[:：]?\s*([A-Z0-9][A-Z0-9\-/]{5,})""").find(l)?.groupValues?.get(1)
            val issuer = Regex("""\b(SGS|TUV|TÜV|Intertek|Bureau Veritas|BV|DNV|UL)\b""").find(l)?.value?.takeIf { it != name }
            val exp = Regex("""(?:expir\w*|valid\w*)\W{0,3}(\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4})""", RegexOption.IGNORE_CASE).find(l)?.groupValues?.get(1)
            val status = if (number != null || issuer != null) "Evidence found but not independently verified" else "Supplier claim only"
            val old = out[name]
            if (old == null || (old.number == null && number != null)) out[name] = CertRow(name, number, issuer, exp, status, "Page text")
        }
    }
    return out.values.toList()
}

fun verification(p: Product, d: PageData?, sup: PageData?): Verif {
    val lines = allLines(p, d, sup)
    val badge = Regex("verified|audited|trade assurance|gold supplier|on-?site check|assessed|inspect", RegexOption.IGNORE_CASE)
    val claim = Regex("manufacturer|factory|trading|OEM|ODM|established|employees|staff|years|yrs|production|capacity|export", RegexOption.IGNORE_CASE)
    val ev = lines.filter { badge.containsMatchIn(it) && it.length < 120 }.take(12)
    val cl = lines.filter { claim.containsMatchIn(it) && !badge.containsMatchIn(it) && it.length < 140 }.take(25)
    val nv = mutableListOf<String>()
    if (cl.any { it.contains("manufactur", true) || it.contains("factory", true) }) nv += "Manufacturer / factory status: supplier claim, no independent evidence found"
    nv += "Business registration (legal representative, capital, licence): not independently checked"
    val certs = certRows(p, d, sup)
    if (certs.isNotEmpty() && certs.all { it.number == null }) nv += "Certificates: no certificate numbers found"
    if (certs.isEmpty()) nv += "Certificates: none found on the pages read"
    return Verif(ev, cl, nv)
}

fun conflicts(p: Product, d: PageData?, sup: PageData?): List<Conflict> {
    val out = mutableListOf<Conflict>()
    // price (listing vs product page, over all tiers)
    val hits = d?.priceLines.orEmpty().mapNotNull { findPrice(it) }.filter { it.cur == normCur(p.currency) }
    val vals = hits.flatMap { listOfNotNull(it.lo, it.hi) }
    if (p.priceText != null && p.minPrice != null && vals.isNotEmpty()) {
        val mn = vals.minOrNull() ?: 0.0
        val mx = vals.maxOrNull() ?: 0.0
        if (p.minPrice < mn * 0.98 || p.minPrice > mx * 1.02)
            out += Conflict("Price", p.priceText, "Search listing", hits.first().text, "Product page")
    }
    // MOQ
    if (p.moq != null && d != null) {
        val pm = moqOf(p.copy(moqText = null, moq = null), d)
        if (pm.first != null && pm.first != p.moq) out += Conflict("MOQ", p.moqText ?: p.moq.toString(), "Search listing", pm.second ?: pm.first.toString(), "Product page")
    }
    // established year
    fun yrs(x: PageData?): List<String> = (x?.facts.orEmpty() + x?.specs.orEmpty().map { it.first + ": " + it.second })
        .filter { Regex("establish|founded|since", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        .flatMap { l -> Regex("""(?:19|20)\d{2}""").findAll(l).map { it.value }.toList() }.distinct()
    val y1 = yrs(d); val y2 = yrs(sup)
    if (y1.isNotEmpty() && y2.isNotEmpty() && y1.intersect(y2.toSet()).isEmpty())
        out += Conflict("Established year", y1.joinToString(", "), "Product page", y2.joinToString(", "), "Supplier profile")
    // supplier name
    fun nn(s: String?) = s?.lowercase()?.filter { it.isLetterOrDigit() } ?: ""
    val names = listOf("Search listing" to p.supplier, "Product page" to d?.supplierName, "Supplier profile" to sup?.supplierName).filter { nn(it.second).length > 5 }
    if (names.size >= 2) {
        val a = names[0]; val b = names[1]
        if (!nn(a.second).contains(nn(b.second)) && !nn(b.second).contains(nn(a.second)))
            out += Conflict("Company name", a.second!!, a.first, b.second!!, b.first)
    }
    return out
}

fun indicators(p: Product, d: PageData?, sup: PageData?): List<Pair<Boolean, String>> {
    val out = mutableListOf<Pair<Boolean, String>>()
    val v = verification(p, d, sup)
    val pi = priceInfo(p, d)
    out += (d != null && d.specs.size >= 5) to if (d == null) "Product page details not fetched yet" else if (d.specs.size >= 5) "Product specifications found (${d.specs.size} fields)" else "Few or no specification fields found"
    out += (sup != null) to if (sup != null) "Supplier profile page read" else "Supplier profile page not read yet"
    out += v.evidence.isNotEmpty() to if (v.evidence.isNotEmpty()) "Platform shows verification / assurance text (platform-reported)" else "No platform verification text found"
    v.notVerified.forEach { out += false to it }
    val c = conflicts(p, d, sup)
    out += c.isEmpty() to if (c.isEmpty()) "No conflicting values found between sources read" else "${c.size} conflicting value(s) between sources"
    if (pi.text == null) out += false to "Price not found"
    if (moqOf(p, d).second == null) out += false to "MOQ not found"
    return out
}

fun missingInfo(p: Product, d: PageData?, sup: PageData?): List<String> {
    val important = setOf("Model number", "Material", "Weight", "Packaging", "Lead time", "Certification", "Sample", "MOQ",
        "Unit price", "Price range", "Starting price", "Price", "Company name", "Website", "Location", "Established", "Legal representative",
        "Registered capital", "Registration no.", "Business type", "Employees", "Production capability", "Export information")
    return (productFields(p, d) + supplierFields(p, d, sup)).filter { it.value == null && it.label in important }.map { it.label }.distinct()
}

// ---------- reports ----------
fun productReport(r: Requirement, p: Product, d: PageData?, sup: PageData?): String = buildString {
    append("■ ${p.title}\nPlatform: ${p.platform}\nProduct page: ${p.url}\n")
    append("\n[Supplier]\n"); supplierFields(p, d, sup).forEach { append("${it.label}: ${it.value ?: NF}\n") }
    append("\n[Product]\n"); productFields(p, d).forEach { append("${it.label}: ${it.value ?: NF}\n") }
    val tiers = priceInfo(p, d).tiers
    if (tiers.isNotEmpty()) { append("\n[Price tiers]\n"); tiers.forEach { append("$it\n") } }
    val rows = matchProduct(r, p, d, sup)
    if (rows.isNotEmpty()) { append("\n[Parameter matching]\n"); rows.forEach { append("${it.param} | required ${it.required} | found ${it.found} | ${it.status.label} | ${it.source}\n") } }
    val v = verification(p, d, sup)
    append("\n[Verification]\nPlatform-reported: ${if (v.evidence.isEmpty()) NF else v.evidence.joinToString("; ")}\n")
    append("Supplier claims (not independent): ${if (v.claims.isEmpty()) NF else v.claims.take(10).joinToString("; ")}\n")
    v.notVerified.forEach { append("Not verified: $it\n") }
    certRows(p, d, sup).forEach { append("Certificate: ${it.name} | no. ${it.number ?: NF} | issuer ${it.issuer ?: NF} | expiry ${it.expiry ?: NF} | ${it.status}\n") }
    val c = conflicts(p, d, sup)
    if (c.isNotEmpty()) { append("\n[CONFLICTING INFORMATION]\n"); c.forEach { append("${it.field}: ${it.aSrc} says ${it.a} / ${it.bSrc} says ${it.b}\n") } }
    append("\n[Warnings]\n"); indicators(p, d, sup).forEach { append((if (it.first) "✓ " else "⚠ ") + it.second + "\n") }
    val miss = missingInfo(p, d, sup)
    append("\n[Missing information]\n${if (miss.isEmpty()) "None of the tracked fields" else miss.joinToString(", ")}\n")
    append("\n[Source links]\n${p.url}\n")
    (d?.links.orEmpty() + sup?.links.orEmpty()).distinctBy { it.second }.forEach { append("${it.second}\n") }
}

fun reportText(s: Session): String = buildString {
    val r = s.req
    append("CHINA SUPPLIER RESEARCH REPORT\n\nA. Research summary\nDate: ${s.date}\nProduct: ${r.name}\nQuantity: ${r.qty.ifBlank { NF }}\n")
    append("Sources checked: ${s.status.entries.joinToString("; ") { it.key + " " + it.value }.ifBlank { NF }}\n")
    append("Listings identified: ${s.products.size}\nDetail pages read: ${s.details.size}\n")
    append("\nC. Comparison (no ranking)\n")
    s.products.forEach { p ->
        val d = s.details[p.url]; val sup = s.suppliers[p.url]
        val sf = supplierFields(p, d, sup)
        append("• ${sf.first().value ?: p.title} | ${p.platform} | Price ${priceInfo(p, d).text ?: NF} | MOQ ${moqOf(p, d).second ?: NF} | Location ${supplierLocation(p, d, sup) ?: NF}\n")
    }
    append("\nD. Individual listings\n\n")
    s.products.filter { s.picked.isEmpty() || it.url in s.picked }.forEach { append(productReport(r, it, s.details[it.url], s.suppliers[it.url])); append("\n") }
}
