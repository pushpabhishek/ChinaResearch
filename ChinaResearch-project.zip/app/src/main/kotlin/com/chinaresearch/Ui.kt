package com.chinaresearch

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage

// Palette: graphite-navy base, brass accent, status colours that are always paired with a glyph
val Bg = Color(0xFF0F131A)
val Panel = Color(0xFF161B24)
val Panel2 = Color(0xFF1D2430)
val Line = Color(0xFF2A3342)
val Gold = Color(0xFFD9BC83)
val TextHi = Color(0xFFE9EDF3)
val TextLo = Color(0xFF8E9AAD)
val Ok = Color(0xFF4CC38A)
val Bad = Color(0xFFF0625D)
val Warn = Color(0xFFF59E42)

val AppScheme = darkColorScheme(
    primary = Gold, onPrimary = Color(0xFF1A1405), background = Bg, surface = Panel, surfaceVariant = Panel2,
    onSurface = TextHi, onBackground = TextHi, onSurfaceVariant = TextLo, outline = Line, secondary = Gold
)

fun Context.open(u: String) {
    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
}

fun Context.share(text: String, title: String = "Share") {
    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, title))
}

fun Status.color(): Color = when (this) { Status.MATCH -> Ok; Status.NO -> Bad; Status.PARTIAL -> Warn; Status.NA -> TextLo }
fun Status.glyph(): String = when (this) { Status.MATCH -> "✓"; Status.NO -> "✕"; Status.PARTIAL -> "!"; Status.NA -> "—" }
fun Status.text(): String = when (this) { Status.MATCH -> "Match"; Status.NO -> "Doesn't match"; Status.PARTIAL -> "Partial / unclear"; Status.NA -> "Unavailable" }

@Composable
fun H1(t: String) = Text(t, fontFamily = FontFamily.Serif, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = TextHi)

@Composable
fun Muted(t: String, modifier: Modifier = Modifier) = Text(t, color = TextLo, fontSize = 12.sp, lineHeight = 17.sp, modifier = modifier)

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp)) {
        Text(title, fontFamily = FontFamily.Serif, fontSize = 18.sp, color = Gold, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun KV(label: String, value: String?, src: String = "") {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, Modifier.width(116.dp), color = TextLo, fontSize = 13.sp)
        Column(Modifier.weight(1f)) {
            if (value == null) Text(NF, color = TextLo.copy(alpha = 0.6f), fontSize = 13.sp, fontStyle = FontStyle.Italic)
            else Text(value, color = TextHi, fontSize = 13.sp, lineHeight = 18.sp)
            if (src.isNotBlank() && value != null) Text(src, color = TextLo, fontSize = 10.sp)
        }
    }
}

@Composable
fun Fields(list: List<Field>) = list.forEach { KV(it.label, it.value, it.source) }

@Composable
fun Chip(text: String, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape).background(color.copy(alpha = 0.14f)).border(1.dp, color.copy(alpha = 0.5f), shape).padding(horizontal = 9.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StatusChip(s: Status) = Chip(s.glyph() + " " + s.text(), s.color())

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (selected) Gold else Panel2).border(1.dp, if (selected) Gold else Line, shape)
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Text(text, color = if (selected) Color(0xFF1A1405) else TextHi, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun Primary(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    Button(
        onClick = onClick, modifier = modifier, enabled = enabled, shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF1A1405), disabledContainerColor = Panel2, disabledContentColor = TextLo)
    ) { Text(text, fontWeight = FontWeight.SemiBold) }

@Composable
fun Ghost(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) =
    OutlinedButton(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextHi)
    ) { Text(text, fontSize = 13.sp) }

@Composable
fun Fld(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier.fillMaxWidth(), lines: Int = 1) =
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, modifier = modifier, minLines = lines, shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold, unfocusedBorderColor = Line, focusedLabelColor = Gold, unfocusedLabelColor = TextLo,
            cursorColor = Gold, focusedContainerColor = Panel, unfocusedContainerColor = Panel
        )
    )

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) TextButton(onClick = onBack) { Text("←", color = Gold, fontSize = 20.sp) }
        else Spacer(Modifier.width(10.dp))
        Text(title, Modifier.weight(1f), fontFamily = FontFamily.Serif, fontSize = 18.sp, color = TextHi, maxLines = 1)
        actions()
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
}

@Composable
fun BottomBar(current: String, go: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
    Row(Modifier.fillMaxWidth().background(Panel).padding(vertical = 6.dp)) {
        listOf("home" to "🔎 Research", "history" to "🕘 History", "settings" to "⚙️ Settings").forEach { (id, label) ->
            Box(Modifier.weight(1f).clickable { go(id) }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                Text(label, color = if (current == id) Gold else TextLo, fontSize = 13.sp, fontWeight = if (current == id) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

// ---------- gallery + viewer ----------
@Composable
fun Gallery(imgs: List<String>, source: String, pageUrl: String) {
    var open by remember { mutableStateOf<Int?>(null) }
    if (imgs.isEmpty()) {
        Text("No images found on the pages read", color = TextLo, fontSize = 13.sp, fontStyle = FontStyle.Italic)
    } else {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(imgs) { i, u ->
                AsyncImage(u, null, Modifier.size(112.dp).clip(RoundedCornerShape(8.dp)).background(Panel2).clickable { open = i }, contentScale = ContentScale.Crop)
            }
        }
        Muted("${imgs.size} image(s) • source: $source • tap to enlarge", Modifier.padding(top = 4.dp))
    }
    val o = open
    if (o != null) Viewer(imgs, o, source, pageUrl) { open = null }
}

@Composable
fun Viewer(imgs: List<String>, start: Int, source: String, pageUrl: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val st = rememberPagerState(initialPage = start) { imgs.size }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(st) { page ->
                var sc by remember { mutableStateOf(1f) }
                var off by remember { mutableStateOf(Offset.Zero) }
                AsyncImage(
                    imgs[page], null,
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> sc = (sc * zoom).coerceIn(1f, 5f); off = if (sc > 1f) off + pan else Offset.Zero } }
                        .graphicsLayer(scaleX = sc, scaleY = sc, translationX = off.x, translationY = off.y),
                    contentScale = ContentScale.Fit
                )
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xCC000000)).padding(12.dp)) {
                Text("${st.currentPage + 1} / ${imgs.size}  •  Source: $source", color = Color.White, fontSize = 13.sp)
                Text(imgs[st.currentPage].take(70), color = TextLo, fontSize = 10.sp, maxLines = 1)
                Row {
                    TextButton(onClick = { ctx.open(pageUrl) }) { Text("Open original page", color = Gold) }
                    TextButton(onClick = { ctx.open(imgs[st.currentPage]) }) { Text("Open image", color = Gold) }
                }
            }
            TextButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd)) { Text("Close", color = Color.White) }
        }
    }
}
