package com.chinaresearch

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import org.json.JSONTokener

private const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

// ======================= HOME =======================
@Composable
fun Home(s: Session, onStart: (Requirement) -> Unit, onSources: () -> Unit) {
    val r0 = s.req
    var name by remember { mutableStateOf(r0.name) }
    var cname by remember { mutableStateOf(r0.chineseName) }
    var cat by remember { mutableStateOf(r0.category) }
    var qty by remember { mutableStateOf(r0.qty) }
    var moq by remember { mutableStateOf(r0.maxMoq?.toString() ?: "") }
    var price by remember { mutableStateOf(r0.maxPrice?.toString() ?: "") }
    var cur by remember { mutableStateOf(r0.currency) }
    var mat by remember { mutableStateOf(r0.material) }
    var size by remember { mutableStateOf(r0.size) }
    var cap by remember { mutableStateOf(r0.capacity) }
    var volt by remember { mutableStateOf(r0.voltage) }
    var power by remember { mutableStateOf(r0.power) }
    var perf by remember { mutableStateOf(r0.performance) }
    var cert by remember { mutableStateOf(r0.certification) }
    var cust by remember { mutableStateOf(r0.customization) }
    var country by remember { mutableStateOf(r0.country) }
    var specs by remember { mutableStateOf(r0.specs.joinToString("\n") { it.first + ": " + it.second }) }
    var notes by remember { mutableStateOf(r0.notes) }
    val srcNames = SOURCES.filter { it.id in s.enabled }.joinToString(", ") { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp)) {
        H1("Sourcing research")
        Muted("Describe what you need. The app searches your enabled sources, reads each product and supplier page, and keeps every fact linked to where it came from.", Modifier.padding(top = 4.dp))
        Section("Product") {
            Fld("Product name (English)", name, { name = it }); Spacer(Modifier.height(8.dp))
            Fld("Chinese name (optional, helps on 1688)", cname, { cname = it }); Spacer(Modifier.height(8.dp))
            Fld("Category", cat, { cat = it })
        }
        Section("Quantity and price") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fld("Quantity", qty, { qty = it }, Modifier.weight(1f)); Fld("Max MOQ", moq, { moq = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Fld("Target / max unit price", price, { price = it })
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Muted("Currency")
                listOf("USD", "CNY", "INR").forEach { c -> Pill(c, cur == c) { cur = c } }
            }
        }
        Section("Specifications") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fld("Material", mat, { mat = it }, Modifier.weight(1f)); Fld("Size / dimension", size, { size = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fld("Capacity", cap, { cap = it }, Modifier.weight(1f)); Fld("Voltage", volt, { volt = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fld("Power", power, { power = it }, Modifier.weight(1f)); Fld("Performance", perf, { perf = it }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Fld("Other specs, one per line (Key: value)", specs, { specs = it }, lines = 3)
        }
        Section("Compliance and location") {
            Fld("Certification (e.g. CE, ISO 9001)", cert, { cert = it }); Spacer(Modifier.height(8.dp))
            Fld("Customization (e.g. logo, OEM)", cust, { cust = it }); Spacer(Modifier.height(8.dp))
            Fld("Country / region", country, { country = it }); Spacer(Modifier.height(8.dp))
            Fld("Notes", notes, { notes = it })
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Muted("Sources: ${srcNames.ifBlank { "none selected" }}", Modifier.weight(1f))
            TextButton(onClick = onSources) { Text("Change", color = Gold) }
        }
        Primary("🔎  RESEARCH PRODUCT", Modifier.fillMaxWidth().height(54.dp), enabled = name.isNotBlank() && s.enabled.isNotEmpty()) {
            val sp = specs.lines().mapNotNull { val i = it.indexOf(':'); if (i > 0) it.substring(0, i).trim() to it.substring(i + 1).trim() else null }
            onStart(Requirement(name.trim(), cname.trim(), cat.trim(), qty.trim(), price.replace(",", "").toDoubleOrNull(), cur, moq.toIntOrNull(),
                mat.trim(), size.trim(), cap.trim(), volt.trim(), power.trim(), perf.trim(), cert.trim(), cust.trim(), country.trim(), sp, notes.trim()))
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ======================= RUNNER / WEBVIEW =======================
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Fetcher(task: Task, desktop: Boolean, onRaw: (String, Boolean) -> String?, onSkip: () -> Unit, onCancel: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    var msg by remember { mutableStateOf("Loading page…") }
    var attempts by remember { mutableStateOf(0) }
    var finished by remember { mutableStateOf(false) }

    fun run(manual: Boolean) {
        val w = web ?: return
        if (finished) return
        if (!manual && attempts >= 3) return
        attempts += 1
        val force = manual || attempts >= 3
        msg = "Reading page…"
        w.evaluateJavascript(task.js) { raw ->
            try {
                val str = JSONTokener(raw).nextValue() as? String
                if (str == null) {
                    msg = "Page returned no data yet. Wait for it to load, then tap Extract now."
                } else {
                    val m = onRaw(str, force)
                    if (m == null) finished = true
                    else { msg = m; if (!manual && attempts < 3 && !finished) w.postDelayed({ run(false) }, 6000) }
                }
            } catch (e: Exception) { msg = "Could not read page: ${e.message}" }
        }
    }
    DisposableEffect(Unit) { onDispose { finished = true; web?.stopLoading(); web?.destroy() } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel2).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Primary("Extract now", Modifier.height(40.dp)) { run(true) }
            Ghost("Skip", Modifier.height(40.dp)) { onSkip() }
            Ghost("Cancel", Modifier.height(40.dp)) { onCancel() }
        }
        val warn = msg.contains("verification", true)
        Text(msg, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), color = if (warn) Warn else TextLo, fontSize = 12.sp)
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                if (desktop) { settings.userAgentString = DESKTOP_UA; settings.useWideViewPort = true; settings.loadWithOverviewMode = true }
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url?.toString() ?: return false
                        return !(u.startsWith("http://") || u.startsWith("https://"))
                    }
                    override fun onPageFinished(v: WebView, u: String) {
                        if (finished) return
                        msg = "Page loaded. Scrolling to load all content…"
                        v.evaluateJavascript(SCROLL_JS, null)
                        v.postDelayed({ run(false) }, 7000)
                    }
                }
                loadUrl(task.url); web = this
            }
        })
    }
}

@Composable
fun Runner(s: Session, onDone: () -> Unit, onCancel: () -> Unit) {
    val task = s.queue.firstOrNull()
    if (task == null) { LaunchedEffect(Unit) { onDone() }; Box(Modifier.fillMaxSize()); return }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text("Research in progress", fontFamily = FontFamily.Serif, fontSize = 18.sp, color = Gold)
            Muted("${task.label}  •  ${s.queue.size} step(s) left")
            for ((k, v) in s.status) Text("$k   $v", color = TextHi, fontSize = 12.sp)
            if (s.details.isNotEmpty() || task.kind != "search") Muted("Product pages read: ${s.details.size}  •  Supplier pages read: ${s.suppliers.size}")
            Muted("If a CAPTCHA or login appears, complete it in the page below. The app never bypasses it.")
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            key(task.id) {
                Fetcher(task, s.desktop, { raw, force -> s.onResult(task, raw, force) }, { s.skip(task) }, onCancel)
            }
        }
    }
}

// ======================= RESULTS =======================
@Composable
fun CheckBox2(checked: Boolean, onChange: (Boolean) -> Unit) =
    Checkbox(checked, onChange, colors = CheckboxDefaults.colors(checkedColor = Gold, checkmarkColor = Color(0xFF1A1405), uncheckedColor = TextLo))

@Composable
fun Results(s: Session, onOpen: (Product) -> Unit, onCompare: () -> Unit, onFetch: () -> Unit, onReport: () -> Unit, onSave: () -> Unit, onNew: () -> Unit) {
    val r = s.req
    var hideNo by remember { mutableStateOf(false) }
    val rowsOf = { p: Product -> matchProduct(r, p, s.details[p.url], s.suppliers[p.url]) }
    val shown = s.products.filter { p -> !hideNo || rowsOf(p).none { it.status == Status.NO } }
    val sufficient = s.products.count { (s.details[it.url]?.specs?.size ?: 0) >= 5 }
    val matching = s.products.count { p -> val rr = rowsOf(p); rr.isNotEmpty() && rr.none { it.status == Status.NO } && rr.any { it.status == Status.MATCH } }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            H1(r.name)
            Muted("${s.date}  •  Quantity: ${r.qty.ifBlank { NF }}")
            Section("Research summary") {
                KV("Sources checked", if (s.status.isEmpty()) null else s.status.entries.joinToString("\n") { it.key + "  " + it.value })
                KV("Listings found", s.products.size.toString())
                KV("Detail pages read", "${s.details.size} product • ${s.suppliers.size} supplier")
                KV("Enough detail", "$sufficient listing(s) with 5+ spec fields")
                KV("Matching so far", if (r.maxPrice == null && r.maxMoq == null && r.material.isBlank() && r.voltage.isBlank() && r.specs.isEmpty()) "No requirements entered" else "$matching listing(s) with no ✕ and at least one ✓")
            }
            Spacer(Modifier.height(10.dp))
            Muted("No ranking is applied. Tick 2–4 listings to compare, or read details for the ticked listings.")
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Primary(if (s.picked.isEmpty()) "Read details" else "Read details (${s.picked.size})", Modifier.weight(1f), enabled = s.products.isNotEmpty()) { onFetch() }
                Ghost("Compare (${s.picked.size})", Modifier.weight(1f)) { if (s.picked.size >= 2) onCompare() }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Ghost("Report", Modifier.weight(1f)) { onReport() }
                Ghost("Save", Modifier.weight(1f)) { onSave() }
                Ghost("New", Modifier.weight(1f)) { onNew() }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) { Pill("Hide listings with ✕", hideNo) { hideNo = !hideNo } }
            if (s.products.isEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text("No sufficiently matching products were found from the researched sources.", color = TextHi, fontSize = 15.sp)
                Muted("Try a simpler product name, enable more sources in Settings, or retry if a source showed a verification page.", Modifier.padding(top = 6.dp))
            }
        }
        items(shown, key = { it.url }) { p -> ProductCard(s, p, rowsOf(p), onOpen) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun ProductCard(s: Session, p: Product, rows: List<Row>, onOpen: (Product) -> Unit) {
    val d = s.details[p.url]
    val pi = priceInfo(p, d)
    val moq = moqOf(p, d).second
    val sup = s.suppliers[p.url]?.supplierName ?: d?.supplierName ?: p.supplier
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).clickable { onOpen(p) }.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AsyncImage(p.image, null, Modifier.size(92.dp).clip(RoundedCornerShape(8.dp)).background(Panel2), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(p.title, maxLines = 2, fontSize = 14.sp, lineHeight = 18.sp, color = TextHi)
            Muted(p.platform + (if (sup != null) "  •  $sup" else ""))
            Text(pi.kind + ": " + (pi.text ?: NF), color = if (pi.text == null) TextLo else Gold, fontSize = 13.sp)
            Text("MOQ: " + (moq ?: NF), color = TextLo, fontSize = 12.sp)
            if (rows.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(Status.MATCH, Status.PARTIAL, Status.NO, Status.NA).forEach { st ->
                    val n = rows.count { it.status == st }
                    if (n > 0) Chip(st.glyph() + " " + n, st.color())
                }
            }
            if (d != null) Muted("Details read" + (if (s.suppliers.containsKey(p.url)) " • supplier read" else ""))
        }
        CheckBox2(p.url in s.picked) { c -> if (c && s.picked.size < 4) s.picked.add(p.url) else s.picked.remove(p.url) }
    }
}

// ======================= DETAIL =======================
@Composable
fun Detail(s: Session, p: Product, onFetch: (Boolean) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val r = s.req
    val d = s.details[p.url]
    val sup = s.suppliers[p.url]
    val rows = matchProduct(r, p, d, sup)
    val pi = priceInfo(p, d)
    val v = verification(p, d, sup)
    val conf = conflicts(p, d, sup)
    var allSpecs by remember { mutableStateOf(false) }
    val mainImgs = (listOfNotNull(p.image) + d?.images.orEmpty().filter { it.second == "gallery" }.map { it.first }).distinct()
    val detailImgs = d?.images.orEmpty().filter { it.second == "detail" }.map { it.first }.filter { it !in mainImgs }
    val supImgs = (sup?.images.orEmpty().map { it.first } + d?.images.orEmpty().filter { it.second == "company" || it.second == "cert" }.map { it.first }).distinct()
    Column(Modifier.fillMaxSize()) {
        TopBar("Listing details", onBack) { TextButton(onClick = { ctx.share(productReport(r, p, d, sup), "Share supplier") }) { Text("Share", color = Gold) } }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(p.title, fontFamily = FontFamily.Serif, fontSize = 20.sp, color = TextHi, lineHeight = 26.sp)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (d == null) Primary("Read product + supplier pages", Modifier.weight(1f)) { onFetch(false) }
                else Ghost("Read again", Modifier.weight(1f)) { onFetch(true) }
                Ghost("Open page", Modifier.weight(1f)) { ctx.open(p.url) }
            }
            if (d != null && sup == null && d.supplierUrl != null) Primary("Read supplier profile", Modifier.fillMaxWidth().padding(top = 6.dp)) { onFetch(false) }

            Section("Product images") { Gallery(mainImgs, p.platform, p.url) }
            if (detailImgs.isNotEmpty()) Section("Detail and specification images") { Gallery(detailImgs, p.platform, p.url) }

            if (rows.isNotEmpty()) Section("Requirement matching") {
                rows.forEach { row ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(row.param, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TextHi)
                            StatusChip(row.status)
                        }
                        Muted("Required: ${row.required}")
                        Muted("Found: ${row.found}  •  ${row.source}")
                    }
                }
            }

            Section("Pricing") {
                KV(pi.kind, pi.text, pi.source); KV("Currency", pi.cur)
                KV("MOQ", moqOf(p, d).second, if (p.moqText != null) "Search listing" else "Product page")
                if (pi.tiers.isNotEmpty()) { Muted("Price tiers on product page"); pi.tiers.forEach { KV("Tier", it) } }
                val ctxLines = (d?.facts.orEmpty()).filter { Regex("shipping|tax|vat|negotiable", RegexOption.IGNORE_CASE).containsMatchIn(it) }.take(4)
                if (ctxLines.isNotEmpty()) { Muted("Shipping / tax text on page"); ctxLines.forEach { Text("• $it", color = TextHi, fontSize = 12.sp) } }
                Muted("A starting or range price is not a quote. Confirm the price for your quantity with the supplier.", Modifier.padding(top = 4.dp))
            }

            Section("Product information") { Fields(productFields(p, d)) }

            Section("All specifications") {
                if (d == null) Muted("Not read yet. Tap “Read product + supplier pages”.")
                else if (d.specs.isEmpty()) Muted(NF)
                else {
                    val list = if (allSpecs) d.specs else d.specs.take(25)
                    list.forEach { KV(it.first, it.second) }
                    if (d.specs.size > 25) TextButton(onClick = { allSpecs = !allSpecs }) { Text(if (allSpecs) "Show fewer" else "Show all ${d.specs.size}", color = Gold) }
                }
            }

            Section("Supplier") { Fields(supplierFields(p, d, sup)) }
            Section("Supplier and factory images") {
                Gallery(supImgs, "Supplier pages", sup?.url ?: d?.supplierUrl ?: p.url)
                Muted("Shown as published by the supplier. A factory photo is not proof that the supplier owns the factory.", Modifier.padding(top = 4.dp))
            }

            Section("Verification") {
                Text("Evidence found (platform-reported, not independent)", color = Ok, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                if (v.evidence.isEmpty()) Muted(NF) else v.evidence.forEach { Text("• $it", color = TextHi, fontSize = 12.sp) }
                Spacer(Modifier.height(8.dp))
                Text("Supplier claims (no independent confirmation)", color = Warn, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                if (v.claims.isEmpty()) Muted(NF) else v.claims.take(15).forEach { Text("• $it", color = TextHi, fontSize = 12.sp) }
                Spacer(Modifier.height(8.dp))
                Text("Not verified", color = TextLo, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                v.notVerified.forEach { Text("• $it", color = TextHi, fontSize = 12.sp) }
            }

            Section("Certification check") {
                val certs = certRows(p, d, sup)
                if (certs.isEmpty()) Muted("No certification text found on the pages read")
                certs.forEach { c ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(c.name, fontWeight = FontWeight.SemiBold, color = TextHi)
                            Chip(c.status, if (c.number != null || c.issuer != null) Warn else TextLo)
                        }
                        Muted("Number: ${c.number ?: NF}  •  Issuer: ${c.issuer ?: NF}  •  Expiry: ${c.expiry ?: NF}")
                    }
                }
                Muted("A certificate is never marked verified from the supplier’s own claim.", Modifier.padding(top = 2.dp))
            }

            Section("Cross-source check") {
                if (conf.isEmpty()) Muted("No conflicting values between the sources read.")
                conf.forEach { c ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text("⚠ CONFLICTING INFORMATION: ${c.field}", color = Warn, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("${c.aSrc}: ${c.a}", color = TextHi, fontSize = 12.sp)
                        Text("${c.bSrc}: ${c.b}", color = TextHi, fontSize = 12.sp)
                    }
                }
            }

            Section("Research warnings") {
                indicators(p, d, sup).forEach { (ok, t) ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(if (ok) "✓" else "⚠", color = if (ok) Ok else Warn, modifier = Modifier.width(22.dp))
                        Text(t, color = TextHi, fontSize = 13.sp)
                    }
                }
            }

            Section("Missing information") {
                val miss = missingInfo(p, d, sup)
                if (miss.isEmpty()) Muted("None of the tracked fields are missing") else Text(miss.joinToString(", "), color = TextHi, fontSize = 13.sp, lineHeight = 19.sp)
            }

            Section("Source links") {
                Ghost("Product page (${p.platform})", Modifier.fillMaxWidth()) { ctx.open(p.url) }
                val links = (listOfNotNull(d?.supplierUrl?.let { "Supplier profile" to it }) + d?.links.orEmpty() + sup?.links.orEmpty()).distinctBy { it.second }
                links.forEach { l -> Ghost((l.first.ifBlank { l.second }).take(44), Modifier.fillMaxWidth().padding(top = 6.dp)) { ctx.open(l.second) } }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ======================= COMPARE =======================
@Composable
fun Compare(s: Session, onBack: () -> Unit) {
    val r = s.req
    val ps = s.products.filter { it.url in s.picked }
    val w = 160.dp
    data class Group(val label: String, val cells: List<String>)
    val groups = mutableListOf<Group>()
    fun g(label: String, f: (Product, PageData?, PageData?) -> String?) { groups += Group(label, ps.map { f(it, s.details[it.url], s.suppliers[it.url]) ?: NF }) }
    g("Platform") { p, _, _ -> p.platform }
    g("Supplier") { p, d, sp -> sp?.supplierName ?: d?.supplierName ?: p.supplier }
    g("Location") { p, d, sp -> supplierLocation(p, d, sp) }
    g("Established / age") { p, d, sp -> val f = supplierFields(p, d, sp); f.firstOrNull { it.label == "Company age" }?.value ?: f.firstOrNull { it.label == "Established" }?.value }
    g("Business type") { p, d, sp -> supplierFields(p, d, sp).firstOrNull { it.label == "Business type" }?.value }
    g("Employees") { p, d, sp -> supplierFields(p, d, sp).firstOrNull { it.label == "Employees" }?.value }
    g("Price") { p, d, _ -> val pi = priceInfo(p, d); pi.text?.let { pi.kind + ": " + it } }
    g("MOQ") { p, d, _ -> moqOf(p, d).second }
    g("Lead time") { _, d, _ -> d?.specs?.find2("lead time", "delivery time") }
    g("Material") { _, d, _ -> d?.specs?.find2("material") }
    g("Size / weight") { _, d, _ -> listOfNotNull(d?.specs?.find2("size", "dimension"), d?.specs?.find2("weight")).joinToString(" • ").ifBlank { null } }
    g("Voltage / power") { _, d, _ -> listOfNotNull(d?.specs?.find2("voltage"), d?.specs?.find2("power", "wattage")).joinToString(" • ").ifBlank { null } }
    g("Customization") { _, d, _ -> d?.specs?.find2("customiz", "oem", "odm") }
    g("Certifications") { p, d, sp -> certRows(p, d, sp).joinToString(", ") { it.name }.ifBlank { null } }
    g("Platform badges") { p, d, sp -> verification(p, d, sp).evidence.firstOrNull() }
    g("Conflicts") { p, d, sp -> conflicts(p, d, sp).size.toString() }
    g("Details read") { p, _, _ -> if (s.details.containsKey(p.url)) (if (s.suppliers.containsKey(p.url)) "Product + supplier" else "Product only") else "Not read" }
    val labels = ps.flatMap { p -> matchProduct(r, p, s.details[p.url], s.suppliers[p.url]).map { it.param } }.distinct()
    val extraKeys = ps.flatMap { p -> s.details[p.url]?.specs?.map { it.first }.orEmpty() }.groupingBy { it }.eachCount().filter { it.value >= 2 }.keys.take(40)
    Column(Modifier.fillMaxSize()) {
        TopBar("Comparison", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Muted("No ranking. Read details for each listing to fill more rows. Swipe sideways to see all columns.")
            Spacer(Modifier.height(8.dp))
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ps.forEach { p ->
                        Column(Modifier.width(w)) {
                            AsyncImage(p.image, null, Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(8.dp)).background(Panel2), contentScale = ContentScale.Crop)
                            Text(p.title, maxLines = 3, fontSize = 12.sp, lineHeight = 16.sp, color = TextHi, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                groups.forEach { gr ->
                    Text(gr.label, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        gr.cells.forEach { c -> Text(c, Modifier.width(w), fontSize = 12.sp, lineHeight = 16.sp, color = if (c == NF) TextLo else TextHi, fontStyle = if (c == NF) FontStyle.Italic else FontStyle.Normal) }
                    }
                }
                if (labels.isNotEmpty()) {
                    Text("Requirement matching", fontFamily = FontFamily.Serif, fontSize = 16.sp, color = Gold, modifier = Modifier.padding(top = 20.dp))
                    labels.forEach { l ->
                        Text(l, color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 3.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ps.forEach { p ->
                                val row = matchProduct(r, p, s.details[p.url], s.suppliers[p.url]).firstOrNull { it.param == l }
                                Column(Modifier.width(w)) {
                                    if (row != null) { StatusChip(row.status); Text(row.found.take(60), color = TextLo, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)) } else Muted("—")
                                }
                            }
                        }
                    }
                }
                if (extraKeys.isNotEmpty()) {
                    Text("Shared specification fields", fontFamily = FontFamily.Serif, fontSize = 16.sp, color = Gold, modifier = Modifier.padding(top = 20.dp))
                    extraKeys.forEach { k ->
                        Text(k, color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 3.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ps.forEach { p ->
                                val v = s.details[p.url]?.specs?.firstOrNull { it.first == k }?.second
                                Text(v ?: NF, Modifier.width(w), fontSize = 12.sp, lineHeight = 16.sp, color = if (v == null) TextLo else TextHi)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

// ======================= REPORT =======================
@Composable
fun ReportScreen(s: Session, onSave: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val text = remember(s.products.size, s.details.size, s.suppliers.size, s.picked.size) { reportText(s) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Research report", onBack)
        Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Primary("Share", Modifier.weight(1f)) { ctx.share(text, "Share report") }
            Ghost("Copy", Modifier.weight(1f)) { clip.setText(AnnotatedString(text)) }
            Ghost("Save", Modifier.weight(1f)) { onSave() }
        }
        Muted(if (s.picked.isEmpty()) "Report lists every listing. Tick listings in Results to limit section D." else "Section D shows only the ticked listings.", Modifier.padding(horizontal = 14.dp))
        SelectionContainer(Modifier.weight(1f)) {
            Text(text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), color = TextHi, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

// ======================= HISTORY =======================
@Composable
fun History(store: Store, onOpen: (Long) -> Unit) {
    var hist by remember { mutableStateOf(store.list()) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Research history", null)
        if (hist.isEmpty()) {
            Column(Modifier.padding(20.dp)) {
                Text("No saved research yet.", color = TextHi, fontSize = 16.sp)
                Muted("Every search is saved here when it finishes. Open one to continue reading details or share the report.", Modifier.padding(top = 6.dp))
            }
        } else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Spacer(Modifier.height(6.dp)) }
            items(hist, key = { it.id }) { h ->
                val shape = RoundedCornerShape(12.dp)
                Row(Modifier.fillMaxWidth().clip(shape).background(Panel).border(1.dp, Line, shape).clickable { onOpen(h.id) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.title, color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Muted("${h.date}  •  ${h.listings} listings  •  ${h.details} detail pages read")
                    }
                    TextButton(onClick = { store.delete(h.id); hist = store.list() }) { Text("Delete", color = Bad) }
                }
            }
        }
    }
}

// ======================= SETTINGS =======================
@Composable
fun SettingsScreen(s: Session, store: Store) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    val sw = SwitchDefaults.colors(checkedThumbColor = Color(0xFF1A1405), checkedTrackColor = Gold, uncheckedTrackColor = Panel2, uncheckedThumbColor = TextLo)
    Column(Modifier.fillMaxSize()) {
        TopBar("Settings", null)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Section("Research sources") {
                SOURCES.forEach { src ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(src.name, color = TextHi, fontSize = 15.sp); Muted(src.note) }
                        Switch(src.id in s.enabled, { on -> if (on) { if (src.id !in s.enabled) s.enabled.add(src.id) } else s.enabled.remove(src.id); store.saveSettings(s) }, colors = sw)
                    }
                }
            }
            Section("Page view") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Desktop site view", color = TextHi, fontSize = 15.sp); Muted("Loads the full desktop pages, which show more specifications and supplier details.") }
                    Switch(s.desktop, { s.desktop = it; store.saveSettings(s) }, colors = sw)
                }
            }
            Section("Exchange rates (optional)") {
                Muted("Used to compare prices shown in another currency with your target price. Enter how many units equal 1 USD.")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Fld("INR per USD", s.inr, { s.inr = it; store.saveSettings(s) }, Modifier.weight(1f))
                    Fld("CNY per USD", s.cny, { s.cny = it; store.saveSettings(s) }, Modifier.weight(1f))
                }
            }
            Section("Data and cache") {
                Ghost("Clear website logins and cache", Modifier.fillMaxWidth()) { store.clearWebData(); msg = "Website data cleared." }
                Spacer(Modifier.height(6.dp))
                Ghost("Delete all saved research", Modifier.fillMaxWidth()) { store.deleteAll(); msg = "History deleted." }
                if (msg.isNotBlank()) Muted(msg, Modifier.padding(top = 6.dp))
            }
            Section("How this app works") {
                Muted("The app reads pages you can open in a normal browser. When a site asks for a CAPTCHA or login, you complete it in the page; the app never bypasses it. Company registry data (legal representative, registered capital) is not available without an official registry source, so those fields show “$NF” unless the supplier publishes them.")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
