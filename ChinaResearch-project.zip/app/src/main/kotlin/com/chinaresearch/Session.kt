package com.chinaresearch

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Session {
    var id by mutableStateOf(0L)
    var req by mutableStateOf(Requirement())
    var date by mutableStateOf("")
    val products = mutableStateListOf<Product>()
    val details = mutableStateMapOf<String, PageData>()
    val suppliers = mutableStateMapOf<String, PageData>()
    val picked = mutableStateListOf<String>()
    val status = mutableStateMapOf<String, String>()
    val queue = mutableStateListOf<Task>()

    // settings
    val enabled = mutableStateListOf("alibaba", "mic")
    var desktop by mutableStateOf(true)
    var inr by mutableStateOf("")
    var cny by mutableStateOf("")

    fun applyRates() { Rates.inr = inr.toDoubleOrNull() ?: 0.0; Rates.cny = cny.toDoubleOrNull() ?: 0.0 }

    fun clearResults() {
        products.clear(); details.clear(); suppliers.clear(); picked.clear(); status.clear(); queue.clear()
    }

    fun start(r: Requirement) {
        clearResults()
        req = r
        id = System.currentTimeMillis()
        date = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date())
        SOURCES.filter { it.id in enabled }.forEach { src ->
            status[src.name] = "🔎 waiting"
            queue.add(Task("search", "Searching ${src.name}", src.url(r.name, r), SEARCH_JS.replace("__PAT__", src.linkPattern), source = src))
        }
    }

    fun enqueueFetch(ps: List<Product>) {
        ps.forEach { p ->
            val d = details[p.url]
            if (d == null) {
                queue.add(Task("product", "Product page: " + p.title.take(40), p.url, PAGE_JS, product = p))
            } else if (!suppliers.containsKey(p.url) && d.supplierUrl != null) {
                queue.add(Task("supplier", "Supplier profile: " + (d.supplierName ?: p.title).take(40), d.supplierUrl, PAGE_JS, product = p))
            }
        }
    }

    fun skip(t: Task) {
        queue.remove(t)
        if (t.kind == "search" && t.source != null) status[t.source.name] = "⚠ skipped or inaccessible"
    }

    /** Returns null when accepted, otherwise a message to show the user. */
    fun onResult(t: Task, raw: String, force: Boolean): String? {
        try {
            when (t.kind) {
                "search" -> {
                    val r = parseSearch(raw, t.source!!.name)
                    if (r.items.isEmpty()) return if (r.blocked) "Human verification required. Complete it in the page, then tap Extract now." else "No listings visible yet. Let the page finish, scroll a little, then tap Extract now."
                    if (r.blocked && !force) return "Human verification may be required. Complete it, then tap Extract now."
                    val have = products.map { it.url }.toSet()
                    products.addAll(r.items.filter { it.url !in have })
                    status[t.source.name] = "✓ ${r.items.size} listings"
                    queue.remove(t)
                }
                "product" -> {
                    val d = parsePage(raw, t.url)
                    if (d.blocked && !force) return "Human verification required. Complete it in the page, then tap Extract now."
                    if (!force && d.specs.size < 3 && d.bodyLen < 3000) return "Page still loading, trying again…"
                    details[t.product!!.url] = d
                    queue.remove(t)
                    if (d.supplierUrl != null && !suppliers.containsKey(t.product.url))
                        queue.add(0, Task("supplier", "Supplier profile: " + (d.supplierName ?: t.product.title).take(40), d.supplierUrl, PAGE_JS, product = t.product))
                }
                else -> {
                    val d = parsePage(raw, t.url)
                    if (d.blocked && !force) return "Human verification required. Complete it in the page, then tap Extract now."
                    if (!force && d.specs.size < 2 && d.facts.size < 3 && d.bodyLen < 2500) return "Page still loading, trying again…"
                    suppliers[t.product!!.url] = d
                    queue.remove(t)
                }
            }
        } catch (e: Exception) {
            return "Could not read page: ${e.message}"
        }
        return null
    }
}
