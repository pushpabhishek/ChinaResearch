package com.chinaresearch

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

val BG = Color(0xFF0D1117); val SURF = Color(0xFF161B22); val SURF2 = Color(0xFF1F2630)
val ACC = Color(0xFF58A6FF); val OK = Color(0xFF3FB950); val BAD = Color(0xFFF85149)
val WARN = Color(0xFFD29922); val MUTE = Color(0xFF8B949E); val TXT = Color(0xFFE6EDF3)

private const val EXTRACT_JS = """(function(){var out=[],seen={};
document.querySelectorAll('a[href*="/product-detail/"]').forEach(function(a){
 var u=a.href.split('?')[0];if(seen[u])return;seen[u]=1;var c=a;
 for(var i=0;i<5&&c.parentElement;i++){c=c.parentElement;if(c.innerText&&c.innerText.length>60)break;}
 var im=c.querySelector('img');
 out.push({url:u,text:c.innerText||'',img:im?(im.currentSrc||im.src||im.getAttribute('data-src')||''):''});});
return JSON.stringify(out);})()"""

private const val DETAIL_JS = """(function(){
var t=document.body?document.body.innerText:'';
var og=document.querySelector('meta[property="og:image"]');
var imgs=[];document.querySelectorAll('img').forEach(function(i){var s=i.currentSrc||i.src||i.getAttribute('data-src')||'';
 if(s&&s.indexOf('http')==0&&(!i.naturalWidth||i.naturalWidth>=150)&&imgs.indexOf(s)<0)imgs.push(s)});
if(og&&og.content)imgs.unshift(og.content);
var attrs=[];document.querySelectorAll('tr').forEach(function(r){var c=r.children;if(c.length==2)attrs.push([c[0].innerText.trim(),c[1].innerText.trim()])});
document.querySelectorAll('dl').forEach(function(d){var k=d.querySelectorAll('dt'),v=d.querySelectorAll('dd');for(var i=0;i<k.length&&i<v.length;i++)attrs.push([k[i].innerText.trim(),v[i].innerText.trim()])});
var sn='',su='';document.querySelectorAll('a[href]').forEach(function(a){
 if(!su&&!/product-detail/.test(a.href)&&/(company_profile|minisite|\.en\.alibaba\.com|\/company)/i.test(a.href)&&a.innerText.trim().length>2){su=a.href;sn=a.innerText.trim()}});
return JSON.stringify({title:document.title,imgs:imgs.slice(0,25),attrs:attrs.slice(0,80),text:t.slice(0,12000),supName:sn,supUrl:su});})()"""

private const val SUPPLIER_JS = """(function(){
var imgs=[];document.querySelectorAll('img').forEach(function(i){var s=i.currentSrc||i.src||i.getAttribute('data-src')||'';
 if(s&&s.indexOf('http')==0&&i.naturalWidth>=200&&imgs.indexOf(s)<0)imgs.push(s)});
return JSON.stringify({title:document.title,text:(document.body?document.body.innerText:'').slice(0,12000),imgs:imgs.slice(0,30)});})()"""

class Bot(val web: WebView, val say: (String) -> Unit) {
    private var loaded = CompletableDeferred<Unit>()
    var resume: CompletableDeferred<Unit>? = null
    init { web.webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView?, u: String?) { loaded.complete(Unit) } } }
    suspend fun load(url: String) {
        loaded = CompletableDeferred(); web.loadUrl(url)
        withTimeoutOrNull(25000) { loaded.await() }; delay(3500)
        web.evaluateJavascript("window.scrollTo(0,document.body.scrollHeight/3)", null); delay(1500)
    }
    suspend fun js(code: String): String = suspendCoroutine { c ->
        web.evaluateJavascript(code) { r -> c.resume((try { JSONTokener(r).nextValue() as? String } catch (e: Exception) { null }) ?: "") }
    }
    suspend fun gate() {
        for (i in 0 until 3) {
            val t = js("(document.body?document.body.innerText:'').slice(0,1200)")
            if (t.length > 1100 || !Regex("(?i)captcha|slide to verify|unusual traffic|verify you are|punish|sign in|log in").containsMatchIn(t)) return
            say("⚠ Human verification required. Complete it in the page below, then tap Continue.")
            resume = CompletableDeferred(); resume!!.await(); resume = null; delay(1500)
        }
    }
}

fun Context.openUrl(u: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
fun Context.share(t: String) = startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }, "Share"))
fun Status.color() = when (this) { Status.MATCH -> OK; Status.NO -> BAD; Status.PARTIAL -> WARN; Status.NA -> MUTE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0D1117.toInt(); window.navigationBarColor = 0xFF0D1117.toInt()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = ACC, onPrimary = Color.Black, background = BG, surface = SURF, onSurface = TXT,
                onBackground = TXT, surfaceVariant = SURF2, onSurfaceVariant = MUTE, outline = Color(0xFF30363D))) { App() }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("home") }
    var req by remember { mutableStateOf(Requirement("", null, "USD", null, emptyList(), "")) }
    var ps by remember { mutableStateOf(listOf<Product>()) }
    var sel by remember { mutableStateOf(0) }
    BackHandler(screen != "home") { screen = if (screen == "detail" || screen == "compare") "results" else "home" }
    Surface(Modifier.fillMaxSize(), color = BG) {
        when (screen) {
            "home" -> Home { req = it; ps = emptyList(); screen = "progress" }
            "progress" -> Progress(req.name, { ps = it }) { screen = "results" }
            "results" -> Results(req, ps, { sel = it; screen = "detail" }, { screen = "compare" }) { screen = "home" }
            "compare" -> Compare(req, ps)
            "detail" -> ps.getOrNull(sel)?.let { Detail(req, it) }
        }
    }
}

@Composable
fun Sec(t: String, c: @Composable ColumnScope.() -> Unit) = Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = SURF)) {
    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(t, color = ACC, fontWeight = FontWeight.Bold); c() }
}
@Composable
fun KV(k: String, v: String) = Row { Text(k, color = MUTE, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(110.dp)); Text(v, color = TXT, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f)) }

@Composable
fun Home(onSearch: (Requirement) -> Unit) {
    var name by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }; var moq by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf("USD") }; var notes by remember { mutableStateOf("") }
    val specKeys = listOf("Material", "Voltage", "Power", "Capacity", "Size", "Certification")
    val specs = remember { mutableStateMapOf<String, String>() }
    Column(Modifier.statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("China Product Research", style = MaterialTheme.typography.headlineSmall, color = TXT, fontWeight = FontWeight.Bold)
        Text("Enter requirement, tap research, review the report.", color = MUTE)
        OutlinedTextField(name, { name = it }, label = { Text("Product name (English)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("USD", "INR", "CNY").forEach { c -> if (cur == c) Button(onClick = { cur = c }) { Text(c) } else OutlinedButton(onClick = { cur = c }) { Text(c) } }
        }
        OutlinedTextField(price, { price = it }, label = { Text("Max unit price ($cur)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(moq, { moq = it }, label = { Text("Max MOQ") }, modifier = Modifier.fillMaxWidth())
        specKeys.forEach { k -> OutlinedTextField(specs[k] ?: "", { specs[k] = it }, label = { Text(k) }, modifier = Modifier.fillMaxWidth()) }
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
            onSearch(Requirement(name.trim(), price.toDoubleOrNull(), cur, moq.toIntOrNull(), specKeys.mapNotNull { k -> specs[k]?.trim()?.takeIf { it.isNotEmpty() }?.let { k to it } }, notes))
        }) { Text("🔎 RESEARCH PRODUCT", fontWeight = FontWeight.Bold) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Progress(query: String, onUpdate: (List<Product>) -> Unit, onDone: () -> Unit) {
    var status by remember { mutableStateOf("Starting...") }
    var web by remember { mutableStateOf<WebView?>(null) }
    var bot by remember { mutableStateOf<Bot?>(null) }
    var stop by remember { mutableStateOf(false) }
    LaunchedEffect(web) {
        val w = web ?: return@LaunchedEffect
        val b = Bot(w) { status = it }; bot = b
        status = "🔎 Searching Alibaba.com..."
        b.load("https://www.alibaba.com/trade/search?SearchText=" + Uri.encode(query)); b.gate()
        var list = listOf<Product>()
        for (i in 0 until 3) {
            list = try { parseProducts(b.js(EXTRACT_JS), "Alibaba.com") } catch (e: Exception) { emptyList() }
            if (list.isNotEmpty()) break
            status = "No listings read yet. Complete any verification/scroll the page, then tap Continue."
            b.resume = CompletableDeferred(); b.resume!!.await(); b.resume = null
        }
        if (list.isEmpty()) { status = "No sufficiently matching products were found from the researched sources."; return@LaunchedEffect }
        list = list.take(6); onUpdate(list)
        for (i in list.indices) {
            if (stop) break
            var p = list[i]
            status = "📋 Product ${i + 1}/${list.size}: reading details..."
            b.load(p.url); b.gate()
            try { p = applyDetail(p, b.js(DETAIL_JS)) } catch (e: Exception) { }
            val su = p.supplier?.url
            if (su != null) {
                status = "🏢 Product ${i + 1}/${list.size}: reading supplier profile..."
                b.load(su); b.gate()
                try { p = applySupplier(p, b.js(SUPPLIER_JS)) } catch (e: Exception) { }
            }
            list = list.toMutableList().also { it[i] = p }; onUpdate(list)
        }
        status = "📊 Preparing report..."; onDone()
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Sec("Research progress") { Text(status, color = TXT) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { bot?.resume?.complete(Unit) }) { Text("Continue") }
            OutlinedButton(onClick = { stop = true; onDone() }) { Text("Show results now") }
        }
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(12.dp)), factory = { ctx ->
            WebView(ctx).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; web = this }
        })
    }
}

@Composable
fun Results(req: Requirement, ps: List<Product>, onOpen: (Int) -> Unit, onCompare: () -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Research report", style = MaterialTheme.typography.headlineSmall, color = TXT, fontWeight = FontWeight.Bold)
            Text("${ps.size} listings · ${ps.count { it.detailLoaded }} detail pages read · no ranking applied", color = MUTE, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(onClick = onCompare, enabled = ps.isNotEmpty()) { Text("Compare all") }
                OutlinedButton(onClick = onBack) { Text("New research") }
            }
        }
        items(ps.size) { i ->
            val p = ps[i]; val rows = matchProduct(req, p)
            Card(Modifier.fillMaxWidth().clickable { onOpen(i) }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = SURF)) {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(p.image, null, Modifier.size(86.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(p.title, maxLines = 2, color = TXT, fontWeight = FontWeight.SemiBold)
                        Text("${p.priceText ?: "Price: $NF"} · MOQ ${p.moqText ?: NF}", color = MUTE, style = MaterialTheme.typography.bodySmall)
                        Text("Supplier: ${p.supplier?.name ?: NF}", color = MUTE, style = MaterialTheme.typography.bodySmall)
                        Text("Matches ${rows.count { it.status == Status.MATCH }}/${rows.size}", color = ACC, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun Compare(req: Requirement, ps: List<Product>) {
    fun fact(p: Product, l: String) = p.supplier?.facts?.firstOrNull { it.label == l }?.value ?: NF
    val simple: List<Pair<String, (Product) -> String>> = listOf(
        "Price" to { p -> p.priceText ?: NF }, "MOQ" to { p -> p.moqText ?: NF }, "Supplier" to { p -> p.supplier?.name ?: NF },
        "Location" to { p -> fact(p, "Location") }, "Established" to { p -> fact(p, "Established") }, "Employees" to { p -> fact(p, "Employees") },
        "Business type" to { p -> fact(p, "Business type") }, "Badges" to { p -> p.supplier?.badges?.joinToString().orEmpty().ifBlank { "None found" } },
        "Spec fields" to { p -> "${p.attrs.size}" })
    val params = ps.flatMap { matchProduct(req, it).map { r -> r.param } }.distinct()
    Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Comparison", style = MaterialTheme.typography.headlineSmall, color = TXT, fontWeight = FontWeight.Bold)
        Column(Modifier.horizontalScroll(rememberScrollState()).padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row { Spacer(Modifier.width(100.dp)); ps.forEachIndexed { i, p -> Text("#${i + 1} ${p.title}", Modifier.width(160.dp).padding(4.dp), maxLines = 2, color = ACC, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall) } }
            simple.forEachIndexed { n, (l, f) -> Row(Modifier.background(if (n % 2 == 0) SURF else BG)) {
                Text(l, Modifier.width(100.dp).padding(4.dp), color = MUTE, style = MaterialTheme.typography.bodySmall)
                ps.forEach { Text(f(it), Modifier.width(160.dp).padding(4.dp), color = TXT, style = MaterialTheme.typography.bodySmall) } } }
            Text("Requirement match", Modifier.padding(top = 10.dp), color = ACC, fontWeight = FontWeight.Bold)
            params.forEach { pr -> Row(Modifier.background(SURF)) {
                Text(pr, Modifier.width(100.dp).padding(4.dp), color = MUTE, style = MaterialTheme.typography.bodySmall)
                ps.forEach { p -> val r = matchProduct(req, p).firstOrNull { it.param == pr }
                    Text(r?.status?.label ?: "—", Modifier.width(160.dp).padding(4.dp), color = r?.status?.color() ?: MUTE, style = MaterialTheme.typography.bodySmall) } } }
        }
        Text("No overall ranking is produced. Missing data is shown as \"$NF\".", color = MUTE, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun Gallery(urls: List<String>, note: String, onOpen: (Int) -> Unit) {
    if (urls.isEmpty()) Text("Images: $NF", color = MUTE) else LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(urls) { i, u -> AsyncImage(u, null, Modifier.size(112.dp).clip(RoundedCornerShape(10.dp)).clickable { onOpen(i) }, contentScale = ContentScale.Crop) }
    }
    Text(note, color = MUTE, style = MaterialTheme.typography.bodySmall)
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun Viewer(urls: List<String>, start: Int, onClose: () -> Unit, onSource: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val st = rememberPagerState(start) { urls.size }
            HorizontalPager(st) { i ->
                var sc by remember { mutableStateOf(1f) }
                AsyncImage(urls[i], null, Modifier.fillMaxSize().pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> sc = (sc * z).coerceIn(1f, 4f) } }
                    .graphicsLayer(scaleX = sc, scaleY = sc), contentScale = ContentScale.Fit)
            }
            Row(Modifier.align(Alignment.TopEnd).padding(12.dp)) { TextButton(onClick = onSource) { Text("Open source page") }; TextButton(onClick = onClose) { Text("Close") } }
            Text("${st.currentPage + 1}/${urls.size}", Modifier.align(Alignment.BottomCenter).padding(16.dp), color = Color.White)
        }
    }
}

@Composable
fun Detail(req: Requirement, p: Product) {
    val ctx = LocalContext.current; val clip = LocalClipboardManager.current
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    val s = p.supplier
    Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(p.title, style = MaterialTheme.typography.titleMedium, color = TXT, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { ctx.openUrl(p.url) }) { Text("Open page") }
            OutlinedButton(onClick = { ctx.share(reportText(req, p)) }) { Text("Share") }
            OutlinedButton(onClick = { clip.setText(AnnotatedString(reportText(req, p))) }) { Text("Copy") }
        }
        Sec("Product gallery") { Gallery(p.images.ifEmpty { listOfNotNull(p.image) }, "Source: ${p.platform} product page. May include related-product images.") { viewer = p.images.ifEmpty { listOfNotNull(p.image) } to it } }
        Sec("Price & MOQ") {
            KV("Price", p.priceText ?: NF); p.priceLines.forEach { Text(it, color = MUTE, style = MaterialTheme.typography.bodySmall) }
            KV("MOQ", p.moqText ?: NF)
        }
        Sec("Requirement matching") {
            val rows = matchProduct(req, p)
            if (rows.isEmpty()) Text("No requirements entered.", color = MUTE)
            rows.forEach { r -> Column { Text(r.param, color = TXT, fontWeight = FontWeight.SemiBold)
                Text("Required: ${r.required} | Found: ${r.found}", color = MUTE, style = MaterialTheme.typography.bodySmall)
                Text("${r.status.label}  ·  ${r.source}", color = r.status.color(), style = MaterialTheme.typography.bodySmall) } }
        }
        Sec("Specifications (${p.attrs.size})") { if (p.attrs.isEmpty()) Text(NF, color = MUTE) else p.attrs.take(40).forEach { KV(it.first, it.second) } }
        Sec("Supplier") {
            KV("Name", s?.name ?: NF); s?.facts?.forEach { KV(it.label, "${it.value}\n(${it.source})") }
            if (s?.facts.isNullOrEmpty()) Text("No company facts found on the pages read.", color = MUTE)
            s?.url?.let { u -> OutlinedButton(onClick = { ctx.openUrl(u) }) { Text("Open supplier profile") } }
            Text("Supplier gallery", color = TXT, fontWeight = FontWeight.SemiBold)
            Gallery(s?.images.orEmpty(), "Source: supplier profile page. Not proof of an actual factory.") { viewer = s?.images.orEmpty() to it }
        }
        Sec("Verification") { verification(p).forEach { KV(it.label, it.value) } }
        Sec("Research warnings") { warnings(p).forEach { Text(it, color = if (it.startsWith("✓")) OK else WARN, style = MaterialTheme.typography.bodySmall) } }
        Sec("Missing information") { Text(missing(p).joinToString("\n• ", prefix = "• "), color = MUTE, style = MaterialTheme.typography.bodySmall) }
        Sec("Source links") { Text("Product: ${p.url}", color = MUTE, style = MaterialTheme.typography.bodySmall); s?.url?.let { Text("Supplier: $it", color = MUTE, style = MaterialTheme.typography.bodySmall) } }
    }
    viewer?.let { (u, i) -> Viewer(u, i, { viewer = null }, { ctx.openUrl(p.url) }) }
}
