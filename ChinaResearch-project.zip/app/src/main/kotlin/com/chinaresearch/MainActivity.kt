package com.chinaresearch

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import org.json.JSONTokener

// Generic extraction: finds product-detail links on the page, takes the surrounding card text + image.
private const val EXTRACT_JS = """(function(){var out=[],seen={};
document.querySelectorAll('a[href*="/product-detail/"]').forEach(function(a){
 if(seen[a.href])return;seen[a.href]=1;var c=a;
 for(var i=0;i<5&&c.parentElement;i++){c=c.parentElement;if(c.innerText&&c.innerText.length>60)break;}
 var im=c.querySelector('img');
 out.push({url:a.href.split('?')[0],text:c.innerText||'',img:im?(im.currentSrc||im.src||im.getAttribute('data-src')||''):''});});
return JSON.stringify(out);})()"""

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("home") }
    var req by remember { mutableStateOf(Requirement("", null, null, "", "")) }
    var products by remember { mutableStateOf(listOf<Product>()) }
    var selected by remember { mutableStateOf<Product?>(null) }
    var status by remember { mutableStateOf("") }
    BackHandler(screen != "home") { screen = if (screen == "detail") "results" else "home" }
    Box(Modifier.statusBarsPadding().navigationBarsPadding()) {
        when (screen) {
            "home" -> Home(req) { req = it; products = emptyList(); status = "Searching Alibaba.com..."; screen = "progress" }
            "progress" -> Progress(req.name, status, { status = it }) { products = it; screen = "results" }
            "results" -> Results(req, products, { selected = it; screen = "detail" }) { screen = "home" }
            "detail" -> Detail(req, selected!!)
        }
    }
}

@Composable
fun Home(initial: Requirement, onSearch: (Requirement) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var price by remember { mutableStateOf("") }
    var moq by remember { mutableStateOf("") }
    var mat by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("China Product Research", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(name, { name = it }, label = { Text("Product Name (English)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(price, { price = it }, label = { Text("Max unit price (US$)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(moq, { moq = it }, label = { Text("Max MOQ") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(mat, { mat = it }, label = { Text("Material") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
            onSearch(Requirement(name.trim(), price.toDoubleOrNull(), moq.toIntOrNull(), mat.trim(), notes))
        }) { Text("🔎 RESEARCH PRODUCT") }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun Progress(query: String, status: String, setStatus: (String) -> Unit, onDone: (List<Product>) -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    fun extract() {
        setStatus("Extracting products...")
        web?.evaluateJavascript(EXTRACT_JS) { raw ->
            try {
                val list = parseProducts(JSONTokener(raw).nextValue() as String, "Alibaba.com")
                if (list.isEmpty()) setStatus("No products found yet. If a CAPTCHA/login is shown, complete it, then tap Extract again.")
                else onDone(list)
            } catch (e: Exception) { setStatus("Could not read this page: ${e.message}") }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Text(status, Modifier.padding(8.dp))
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { extract() }) { Text("Extract now") }
        }
        Text("Human verification required? Complete it below.", Modifier.padding(8.dp), style = MaterialTheme.typography.bodySmall)
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true; settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, url: String) {
                        setStatus("Page loaded. Tap 'Extract now' once products are visible.")
                    }
                }
                loadUrl("https://www.alibaba.com/trade/search?SearchText=" + Uri.encode(query))
                web = this
            }
        })
    }
}

@Composable
fun Results(req: Requirement, products: List<Product>, onOpen: (Product) -> Unit, onBack: () -> Unit) {
    LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("${products.size} listings found (Alibaba.com)", style = MaterialTheme.typography.titleMedium)
            Text("No ranking is applied. Supplier/company data: open a listing.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onBack) { Text("New research") } }
        items(products) { p ->
            val rows = matchProduct(req, p)
            Card(Modifier.fillMaxWidth(), onClick = { onOpen(p) }) {
                Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AsyncImage(p.image, null, Modifier.size(80.dp))
                    Column {
                        Text(p.title, maxLines = 2)
                        Text("Price: ${p.priceText ?: "Information Not Found"}  |  MOQ: ${p.moqText ?: "Information Not Found"}", style = MaterialTheme.typography.bodySmall)
                        rows.forEach { Text("${it.param}: ${it.status.label}", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}

@Composable
fun Detail(req: Requirement, p: Product) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AsyncImage(p.image, "Product image (source: ${p.platform})", Modifier.fillMaxWidth().height(240.dp))
        Text(p.title, style = MaterialTheme.typography.titleMedium)
        Text("Platform: ${p.platform}\nPrice: ${p.priceText ?: "Information Not Found"}\nMOQ: ${p.moqText ?: "Information Not Found"}")
        Text("Parameter Matching", style = MaterialTheme.typography.titleSmall)
        matchProduct(req, p).ifEmpty { listOf(Row("-", "No requirements entered", "-", Status.NA)) }.forEach {
            Text("${it.param} | ${it.required} | ${it.found} | ${it.status.label}")
        }
        Text("Supplier verification: Information Not Found (planned: next phase)", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.url))) }) { Text("Open Original Product Page") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${p.title}\n${p.priceText}\n${p.moqText}\n${p.url}") }, "Share"))
        }) { Text("Share") }
    }
}
