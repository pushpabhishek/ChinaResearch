package com.chinaresearch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = AppScheme) { Surface(Modifier.fillMaxSize(), color = Bg) { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val s = remember { Session().also { store.loadSettings(it) } }
    var screen by remember { mutableStateOf("home") }
    var backTo by remember { mutableStateOf("results") }
    var selected by remember { mutableStateOf<Product?>(null) }
    val roots = listOf("home", "history", "settings")

    BackHandler(screen != "home") {
        when (screen) {
            "runner" -> { s.queue.clear(); screen = if (s.products.isEmpty() && backTo == "results") "home" else backTo }
            "detail", "compare", "report" -> screen = "results"
            else -> screen = "home"
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (screen) {
                "home" -> Home(s, onStart = { r -> s.start(r); backTo = "results"; screen = "runner" }, onSources = { screen = "settings" })
                "runner" -> Runner(s,
                    onDone = { store.save(s); screen = backTo },
                    onCancel = { s.queue.clear(); store.save(s); screen = if (s.products.isEmpty()) "home" else backTo })
                "results" -> Results(s,
                    onOpen = { selected = it; screen = "detail" },
                    onCompare = { screen = "compare" },
                    onFetch = {
                        val targets = if (s.picked.isEmpty()) s.products.take(10) else s.products.filter { it.url in s.picked }
                        s.enqueueFetch(targets); backTo = "results"; if (s.queue.isNotEmpty()) screen = "runner"
                    },
                    onReport = { screen = "report" },
                    onSave = { store.save(s) },
                    onNew = { screen = "home" })
                "detail" -> {
                    val p = selected
                    if (p != null) Detail(s, p,
                        onFetch = { again ->
                            if (again) { s.details.remove(p.url); s.suppliers.remove(p.url) }
                            s.enqueueFetch(listOf(p)); backTo = "detail"; if (s.queue.isNotEmpty()) screen = "runner"
                        },
                        onBack = { screen = "results" })
                }
                "compare" -> Compare(s) { screen = "results" }
                "report" -> ReportScreen(s, onSave = { store.save(s) }, onBack = { screen = "results" })
                "history" -> History(store) { id -> if (store.load(id, s)) { backTo = "results"; screen = "results" } }
                "settings" -> SettingsScreen(s, store)
            }
        }
        if (screen in roots) BottomBar(screen) { screen = it }
    }
}
